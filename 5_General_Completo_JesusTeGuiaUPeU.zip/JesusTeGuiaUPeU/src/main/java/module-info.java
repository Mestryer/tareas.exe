/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : module-info.java                                             │
 * │ CAPA    : Configuración                                                │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Declara los módulos de Java que usa el proyecto (JavaFX, SQL,        │
 * │   validación, logs) y qué paquetes se abren a JavaFX para leer los     │
 * │   modelos en las tablas.                                               │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
module pe.edu.upeu.syspasajes {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires static lombok;

    requires java.sql;
    requires java.naming;
    requires org.slf4j;
    requires com.zaxxer.hikari;
    requires java.prefs;
    requires javafx.base;

    requires jakarta.validation;
    requires org.jsoup;
    requires java.net.http;   // para consultar el RUC en la API de SUNAT
    requires java.desktop;    // para abrir WhatsApp con el aviso de reserva al taxista

    opens pe.edu.upeu.syspasajes.controller to javafx.fxml;
    opens pe.edu.upeu.syspasajes to javafx.fxml;
    opens pe.edu.upeu.syspasajes.model;
    opens pe.edu.upeu.syspasajes.dto;

    exports pe.edu.upeu.syspasajes;
    exports pe.edu.upeu.syspasajes.model;
}
