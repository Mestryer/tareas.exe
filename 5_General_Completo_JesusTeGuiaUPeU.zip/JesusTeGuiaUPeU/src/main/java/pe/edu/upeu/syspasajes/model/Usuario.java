/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Usuario.java                                                 │
 * │ CAPA    : Modelo (datos)                                               │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Usuario que ingresa con contraseña (administrador o taxista).        │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Usuario {
    private Long idUsuario;
    private String usuario;
    private String clave;
    private Perfil idPerfil;
    private String estado;
}