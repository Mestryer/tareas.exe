/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : PanelClienteController.java                                  │
 * │ CAPA    : Controlador (la vista se arma con código JavaFX)             │
 * │ MÓDULO  : Panel del cliente (autoservicio)                             │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Pantalla para que el MISMO CLIENTE compre su pasaje sin taxista:     │
 * │   1) se identifica con su DNI (si es nuevo se registra)                │
 * │   2) elige sentido, tipo de vehículo, fecha y salida                   │
 * │   3) elige su(s) asiento(s) en el croquis                              │
 * │   4) revisa su carrito                                                 │
 * │   5) paga con Yape, Plin, tarjeta o transferencia y recibe su boleta   │
 * │      o factura (con búsqueda automática del RUC en SUNAT).             │
 * │   Reutiliza los mismos servicios que la venta del taxista.             │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import pe.edu.upeu.syspasajes.components.ColumnInfo;
import pe.edu.upeu.syspasajes.components.MapaAsientos;
import pe.edu.upeu.syspasajes.components.TableViewHelper;
import pe.edu.upeu.syspasajes.components.Toast;
import pe.edu.upeu.syspasajes.config.AppContext;
import pe.edu.upeu.syspasajes.dto.ComboBoxOption;
import pe.edu.upeu.syspasajes.dto.DatosPago;
import pe.edu.upeu.syspasajes.dto.PersonaDto;
import pe.edu.upeu.syspasajes.enums.MetodoPago;
import pe.edu.upeu.syspasajes.enums.Sentido;
import pe.edu.upeu.syspasajes.enums.TipoComprobante;
import pe.edu.upeu.syspasajes.enums.TipoDocumento;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Cliente;
import pe.edu.upeu.syspasajes.model.Usuario;
import pe.edu.upeu.syspasajes.model.VentaCarrito;
import pe.edu.upeu.syspasajes.model.VentaPasaje;
import pe.edu.upeu.syspasajes.model.Viaje;
import pe.edu.upeu.syspasajes.service.IClienteService;
import pe.edu.upeu.syspasajes.service.IUsuarioService;
import pe.edu.upeu.syspasajes.service.IVentaCarritoService;
import pe.edu.upeu.syspasajes.service.IVentaPasajeService;
import pe.edu.upeu.syspasajes.service.IViajeService;
import pe.edu.upeu.syspasajes.utils.ConsultaDNI;
import pe.edu.upeu.syspasajes.utils.ConsultaRUC;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

public class PanelClienteController {

    // Usuario interno "autoservicio" (id 7 en schema_pasajes.sql): queda como vendedor de estas compras
    private static final long ID_USUARIO_AUTOSERVICIO = 7L;

    // ----- Servicios (los entrega AppContext por el constructor) -----
    private final IClienteService clienteService;
    private final IViajeService viajeService;
    private final IVentaCarritoService carritoService;
    private final IUsuarioService usuarioService;
    private final IVentaPasajeService ventaService;
    private final ConsultaDNI consultaDNI;
    private final ConsultaRUC consultaRUC;

    // ----- Estado de la pantalla -----
    private Stage stage;
    private Cliente cliente;      // cliente identificado (null = todavía no ingresó su DNI)
    private Viaje viajeSel;       // salida elegida en la tabla

    // ----- Controles de la pantalla -----
    private Label lblBienvenida;
    private TextField txtDni, txtNombres, txtCelular;
    private Button btnIdentificar, btnRegistrarme;
    private VBox cardSalida, cardAsientos, cardCarrito, cardPago;
    private ComboBox<Sentido> cbxSentido;
    private ComboBox<ComboBoxOption> cbxTipo;
    private DatePicker dpFecha;
    private TableView<Viaje> tablaViajes;
    private MapaAsientos mapa;
    private Label lblViaje, lblSeleccion;
    private Button btnAgregar;
    private TableView<VentaCarrito> tablaCarrito;
    private Label lblBase, lblIgv, lblTotal;
    private ComboBox<TipoComprobante> cbxComprobante;
    private ComboBox<MetodoPago> cbxMetodo;
    private TextField txtRuc, txtRazon, txtOperacion;
    private Button btnPagar;

    public PanelClienteController(IClienteService clienteService, IViajeService viajeService,
                                  IVentaCarritoService carritoService, IUsuarioService usuarioService,
                                  IVentaPasajeService ventaService, ConsultaDNI consultaDNI,
                                  ConsultaRUC consultaRUC) {
        this.clienteService = clienteService;
        this.viajeService = viajeService;
        this.carritoService = carritoService;
        this.usuarioService = usuarioService;
        this.ventaService = ventaService;
        this.consultaDNI = consultaDNI;
        this.consultaRUC = consultaRUC;
    }

    // =====================================================================
    //  ABRIR Y CERRAR EL PANEL
    // =====================================================================

    /** Cambia la ventana del login por el panel del cliente. */
    public void mostrar(Stage stage) {
        this.stage = stage;
        this.cliente = null;
        this.viajeSel = null;
        carritoService.liberarReservasVencidas();   // borra reservas de más de 15 minutos

        Scene scene = new Scene(crearVista(), 1180, 740);
        MainguiController.aplicarTemaGuardado(scene);   // mismo tema de colores del sistema
        stage.setTitle("Jesús te guía a la UPeU | Compra tu pasaje");
        stage.setResizable(true);
        stage.setScene(scene);
        stage.centerOnScreen();
        habilitarPasos(false);   // hasta que el cliente se identifique
        listarViajes();
        txtDni.requestFocus();
    }

    /** Vuelve a la ventana de ingreso (login). */
    private void salir() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/view/login.fxml"));
            loader.setControllerFactory(AppContext.getInstance()::getBean);
            Scene scene = new Scene(loader.load());
            scene.getStylesheets().add(getClass().getResource("/css/login.css").toExternalForm());
            stage.setTitle("Jesús te guía a la UPeU - Ingreso");
            stage.setResizable(false);
            stage.setScene(scene);
            stage.sizeToScene();
            stage.centerOnScreen();
        } catch (Exception e) {
            Toast.mostrar(stage, "No se pudo volver al ingreso: " + e.getMessage(), Toast.ERROR);
        }
    }

    // =====================================================================
    //  DISEÑO DE LA PANTALLA (se arma con código, sin FXML)
    // =====================================================================

    private Parent crearVista() {
        // ---- Encabezado: logo, título, saludo y botón Salir ----
        ImageView logo = new ImageView(new Image(getClass().getResourceAsStream("/img/logo_jesus.png")));
        logo.setFitHeight(48);
        logo.setPreserveRatio(true);
        Label titulo = new Label("Compra tu pasaje");
        titulo.getStyleClass().add("banner-titulo");
        lblBienvenida = new Label("Ingresa tu DNI para empezar");
        lblBienvenida.getStyleClass().add("banner-subtitulo");
        VBox textos = new VBox(2, titulo, lblBienvenida);
        Region espacio = new Region();
        HBox.setHgrow(espacio, Priority.ALWAYS);
        Button btnSalir = new Button("Salir");
        btnSalir.getStyleClass().add("btn-secundario");
        btnSalir.setOnAction(e -> salir());
        HBox encabezado = new HBox(14, logo, textos, espacio, btnSalir);
        encabezado.setAlignment(Pos.CENTER_LEFT);
        encabezado.setPadding(new Insets(12, 18, 12, 18));
        encabezado.getStyleClass().add("banner");

        // ---- Columna izquierda: pasos 1, 2 y 3 ----
        VBox izquierda = new VBox(12, crearPasoCliente(), crearPasoSalida(), crearPasoAsientos());
        // ---- Columna derecha: pasos 4 y 5 ----
        VBox derecha = new VBox(12, crearPasoCarrito(), crearPasoPago());
        izquierda.setPrefWidth(640);
        derecha.setPrefWidth(480);
        HBox.setHgrow(izquierda, Priority.ALWAYS);
        HBox.setHgrow(derecha, Priority.ALWAYS);
        HBox columnas = new HBox(14, izquierda, derecha);
        columnas.setPadding(new Insets(14));

        ScrollPane scroll = new ScrollPane(columnas);
        scroll.setFitToWidth(true);
        scroll.getStyleClass().add("fondo-panel");

        BorderPane raiz = new BorderPane(scroll);
        raiz.setTop(encabezado);
        raiz.getStyleClass().add("fondo-panel");
        return raiz;
    }

    /** Crea una "tarjeta" (recuadro) con su título. */
    private VBox tarjeta(String titulo) {
        Label lbl = new Label(titulo);
        lbl.getStyleClass().add("titulo-seccion");
        VBox card = new VBox(8, lbl);
        card.setPadding(new Insets(12));
        card.getStyleClass().add("tarjeta");
        return card;
    }

    // ---------------------------- PASO 1 ----------------------------
    private VBox crearPasoCliente() {
        VBox card = tarjeta("1. Identifícate con tu DNI");
        txtDni = new TextField();
        txtDni.setPromptText("DNI (8 dígitos)");
        // Solo deja escribir números, máximo 8
        txtDni.textProperty().addListener((o, viejo, nuevo) -> {
            if (nuevo != null && !nuevo.matches("\\d{0,8}")) txtDni.setText(viejo);
        });
        txtDni.setOnAction(e -> identificar());   // Enter = Ingresar
        btnIdentificar = new Button("Ingresar");
        btnIdentificar.getStyleClass().add("btn-principal");
        btnIdentificar.setOnAction(e -> identificar());
        HBox filaDni = new HBox(8, txtDni, btnIdentificar);
        HBox.setHgrow(txtDni, Priority.ALWAYS);

        txtNombres = new TextField();
        txtNombres.setPromptText("Nombres y apellidos");
        txtCelular = new TextField();
        txtCelular.setPromptText("Celular (opcional, 9 dígitos)");
        btnRegistrarme = new Button("Registrarme");
        btnRegistrarme.getStyleClass().add("btn-principal");
        btnRegistrarme.setOnAction(e -> registrarme());
        // El formulario de registro solo se ve si el DNI es nuevo
        VBox registro = new VBox(6, new Label("Eres nuevo: completa tus datos"), txtNombres, txtCelular, btnRegistrarme);
        registro.visibleProperty().bind(btnRegistrarme.disableProperty().not());
        registro.managedProperty().bind(registro.visibleProperty());
        btnRegistrarme.setDisable(true);

        card.getChildren().addAll(filaDni, registro);
        return card;
    }

    /** Busca al cliente por su DNI. Si no existe consulta RENIEC y muestra el registro. */
    private void identificar() {
        String dni = txtDni.getText() == null ? "" : txtDni.getText().trim();
        if (!dni.matches("\\d{8}")) {
            Toast.mostrar(stage, "Escribe tu DNI de 8 dígitos", Toast.AVISO);
            return;
        }
        Optional<Cliente> encontrado = clienteService.buscar(dni);
        if (encontrado.isPresent()) {
            entrarComo(encontrado.get());
            return;
        }
        // Cliente nuevo: se consulta RENIEC en otro hilo para no congelar la ventana
        btnRegistrarme.setDisable(false);
        txtNombres.clear();
        btnIdentificar.setDisable(true);
        btnIdentificar.setText("Buscando...");
        Task<PersonaDto> tarea = new Task<>() {
            @Override
            protected PersonaDto call() {
                return consultaDNI.consultarDNI(dni);
            }
        };
        tarea.setOnSucceeded(ev -> {
            restaurarBotonIngresar();
            PersonaDto p = tarea.getValue();
            if (p != null && p.getNombre() != null && !p.getNombre().isBlank()) {
                txtNombres.setText(p.getNombre() + " " + p.getApellidoPaterno() + " " + p.getApellidoMaterno());
            }
            Toast.mostrar(stage, "No estás registrado. Revisa tus datos y pulsa \"Registrarme\".", Toast.INFO);
            txtCelular.requestFocus();
        });
        tarea.setOnFailed(ev -> {
            restaurarBotonIngresar();
            Toast.mostrar(stage, "Escribe tus nombres y pulsa \"Registrarme\".", Toast.AVISO);
            txtNombres.requestFocus();
        });
        Thread hilo = new Thread(tarea, "panel-cliente-dni");
        hilo.setDaemon(true);
        hilo.start();
    }

    private void restaurarBotonIngresar() {
        btnIdentificar.setDisable(false);
        btnIdentificar.setText("Ingresar");
    }

    /** Registra al cliente nuevo y lo deja identificado. */
    private void registrarme() {
        String dni = txtDni.getText().trim();
        String nombres = txtNombres.getText() == null ? "" : txtNombres.getText().trim().toUpperCase();
        String cel = txtCelular.getText() == null ? "" : txtCelular.getText().trim();
        // VALIDACIONES
        if (!dni.matches("\\d{8}")) {
            Toast.mostrar(stage, "El DNI debe tener 8 dígitos", Toast.AVISO);
            return;
        }
        if (nombres.isEmpty()) {
            Toast.mostrar(stage, "Escribe tus nombres y apellidos", Toast.AVISO);
            txtNombres.requestFocus();
            return;
        }
        if (!cel.isEmpty() && !cel.matches("9\\d{8}")) {
            Toast.mostrar(stage, "El celular debe tener 9 dígitos y empezar con 9", Toast.AVISO);
            txtCelular.requestFocus();
            return;
        }
        try {
            Cliente nuevo = Cliente.builder()
                    .dni(dni)
                    .nombres(nombres.length() > 80 ? nombres.substring(0, 80) : nombres)
                    .telefono(cel.isEmpty() ? null : cel)
                    .tipoDocumento(TipoDocumento.DNI)
                    .build();
            clienteService.save(nuevo);
            Toast.mostrar(stage, "¡Registro exitoso!", Toast.EXITO);
            entrarComo(nuevo);
        } catch (Exception e) {
            Toast.mostrar(stage, "No se pudo registrar: " + e.getMessage(), Toast.ERROR);
        }
    }

    /** Deja al cliente identificado y habilita los demás pasos. */
    private void entrarComo(Cliente c) {
        cliente = c;
        btnRegistrarme.setDisable(true);
        txtDni.setDisable(true);
        btnIdentificar.setDisable(true);
        lblBienvenida.setText("¡Hola, " + c.getNombres() + "! Elige tu salida y tu asiento");
        habilitarPasos(true);
        listarCarrito();
        Toast.mostrar(stage, "Bienvenido(a) " + c.getNombres(), Toast.EXITO);
    }

    private void habilitarPasos(boolean activo) {
        cardSalida.setDisable(!activo);
        cardAsientos.setDisable(!activo);
        cardCarrito.setDisable(!activo);
        cardPago.setDisable(!activo);
    }

    // ---------------------------- PASO 2 ----------------------------
    private VBox crearPasoSalida() {
        cardSalida = tarjeta("2. Elige tu salida");
        cbxSentido = new ComboBox<>(FXCollections.observableArrayList(Sentido.values()));
        cbxSentido.getSelectionModel().select(Sentido.UPEU_PLAZA);
        cbxTipo = new ComboBox<>(FXCollections.observableArrayList(
                new ComboBoxOption("", "Taxi y Combi"),
                new ComboBoxOption(TipoVehiculo.TAXI.name(), "Solo Taxi (4 asientos)"),
                new ComboBoxOption(TipoVehiculo.COMBI.name(), "Solo Combi (10 asientos)")));
        cbxTipo.getSelectionModel().selectFirst();
        dpFecha = new DatePicker(LocalDate.now());
        // Cada cambio de filtro vuelve a buscar las salidas
        cbxSentido.setOnAction(e -> listarViajes());
        cbxTipo.setOnAction(e -> listarViajes());
        dpFecha.setOnAction(e -> listarViajes());
        HBox filtros = new HBox(8, cbxSentido, cbxTipo, dpFecha);
        filtros.setAlignment(Pos.CENTER_LEFT);

        tablaViajes = new TableView<>();
        LinkedHashMap<String, ColumnInfo> col = new LinkedHashMap<>();
        col.put("Salida", new ColumnInfo("horaTexto", 65.0));
        col.put("Vehículo", new ColumnInfo("tipoTexto", 75.0));
        col.put("Placa", new ColumnInfo("placa", 80.0));
        col.put("Conductor", new ColumnInfo("conductor", 170.0));
        col.put("Libres", new ColumnInfo("libresTexto", 65.0));
        col.put("Precio", new ColumnInfo("precioTexto", 75.0));
        new TableViewHelper<Viaje>().addColumnsInOrderWithSize(tablaViajes, col);
        tablaViajes.setPlaceholder(new Label("No hay salidas disponibles para esa fecha"));
        tablaViajes.setPrefHeight(180);
        // Al elegir una salida se dibujan sus asientos
        tablaViajes.getSelectionModel().selectedItemProperty().addListener((o, viejo, nuevo) -> {
            viajeSel = nuevo;
            dibujarMapa();
        });

        cardSalida.getChildren().addAll(filtros, tablaViajes);
        return cardSalida;
    }

    /** Lista las salidas del día elegido que todavía no partieron. */
    private void listarViajes() {
        if (tablaViajes == null) return;
        carritoService.liberarReservasVencidas();
        LocalDate fecha = dpFecha.getValue();
        if (fecha == null || fecha.isBefore(LocalDate.now())) {
            // No se venden pasajes de días pasados
            fecha = LocalDate.now();
            dpFecha.setValue(fecha);
        }
        Sentido sentido = cbxSentido.getValue();
        ComboBoxOption op = cbxTipo.getValue();
        TipoVehiculo tipo = (op == null || op.getKey().isEmpty()) ? null : TipoVehiculo.valueOf(op.getKey());
        List<Viaje> lista = viajeService.listarDisponibles(fecha, sentido, tipo).stream()
                .filter(v -> !v.yaPartio())
                .toList();
        Long idAnterior = viajeSel == null ? null : viajeSel.getIdViaje();
        tablaViajes.setItems(FXCollections.observableArrayList(lista));
        // Mantiene elegida la misma salida después de refrescar
        if (idAnterior != null) {
            lista.stream().filter(v -> v.getIdViaje().equals(idAnterior)).findFirst()
                    .ifPresent(v -> tablaViajes.getSelectionModel().select(v));
        }
        if (tablaViajes.getSelectionModel().getSelectedItem() == null) {
            viajeSel = null;
            dibujarMapa();
        }
    }

    // ---------------------------- PASO 3 ----------------------------
    private VBox crearPasoAsientos() {
        cardAsientos = tarjeta("3. Elige tu asiento");
        lblViaje = new Label("Ninguna salida elegida");
        mapa = new MapaAsientos();   // mismo croquis que usa el taxista
        mapa.setOnCambioSeleccion(this::actualizarSeleccion);
        lblSeleccion = new Label("Haz clic en los asientos verdes");
        lblSeleccion.getStyleClass().add("seleccion-texto");
        btnAgregar = new Button("Agregar al carrito");
        btnAgregar.getStyleClass().add("btn-principal");
        btnAgregar.setDisable(true);
        btnAgregar.setOnAction(e -> agregarAlCarrito());
        cardAsientos.getChildren().addAll(lblViaje, mapa, lblSeleccion, btnAgregar);
        return cardAsientos;
    }

    private void dibujarMapa() {
        if (mapa == null) return;
        if (viajeSel == null) {
            lblViaje.setText("Ninguna salida elegida");
            mapa.mostrarMensaje("Elige una salida de la lista\npara ver sus asientos");
            actualizarSeleccion();
            return;
        }
        Set<Integer> ocupados = viajeService.asientosOcupados(viajeSel.getIdViaje());
        lblViaje.setText(viajeSel.getTipoTexto() + " " + viajeSel.getPlaca() + "  |  Sale " + viajeSel.getFechaTexto()
                + " " + viajeSel.getHoraTexto() + "  |  " + viajeSel.getPrecioTexto() + " por asiento");
        mapa.dibujar(viajeSel.getVehiculo().getTipoVehiculo(), viajeSel.getCapacidad(), ocupados, viajeSel.getPlaca());
        actualizarSeleccion();
    }

    /** Muestra los asientos marcados y su importe. */
    private void actualizarSeleccion() {
        Set<Integer> sel = mapa.getSeleccionados();
        if (sel.isEmpty() || viajeSel == null) {
            lblSeleccion.setText("Haz clic en los asientos verdes");
            btnAgregar.setDisable(true);
        } else {
            double importe = sel.size() * viajeSel.getPrecio();
            lblSeleccion.setText("Asiento(s): " + sel.stream().map(String::valueOf).collect(Collectors.joining(", "))
                    + "   →   " + String.format("S/ %.2f", importe));
            btnAgregar.setDisable(false);
        }
    }

    /** Reserva los asientos marcados por 15 minutos (van al carrito). */
    private void agregarAlCarrito() {
        if (cliente == null || viajeSel == null || mapa.getSeleccionados().isEmpty()) return;
        if (viajeSel.yaPartio()) {
            Toast.mostrar(stage, "Esta salida ya partió. Elige otra.", Toast.ERROR);
            listarViajes();
            return;
        }
        try {
            Usuario autoservicio = usuarioService.findById(ID_USUARIO_AUTOSERVICIO);
            List<Integer> fallidos = carritoService.reservarAsientos(cliente.getDni(), viajeSel,
                    new ArrayList<>(mapa.getSeleccionados()), autoservicio);
            if (fallidos.isEmpty()) {
                Toast.mostrar(stage, "Asiento(s) en tu carrito. Tienes " + IVentaCarritoService.MINUTOS_RESERVA
                        + " minutos para pagar.", Toast.EXITO);
            } else {
                Toast.mostrar(stage, "Los asientos " + fallidos + " acaban de ser ocupados. Elige otros.", Toast.AVISO);
            }
        } catch (Exception e) {
            Toast.mostrar(stage, "No se pudo reservar: " + e.getMessage(), Toast.ERROR);
        }
        listarCarrito();
        listarViajes();
        dibujarMapa();
    }

    // ---------------------------- PASO 4 ----------------------------
    private VBox crearPasoCarrito() {
        cardCarrito = tarjeta("4. Tu carrito");
        tablaCarrito = new TableView<>();
        LinkedHashMap<String, ColumnInfo> col = new LinkedHashMap<>();
        col.put("Asiento", new ColumnInfo("nroAsiento", 65.0));
        col.put("Salida", new ColumnInfo("salidaTexto", 120.0));
        col.put("Vehículo", new ColumnInfo("vehiculoTexto", 120.0));
        col.put("Precio", new ColumnInfo("precioTexto", 75.0));
        new TableViewHelper<VentaCarrito>().addColumnsInOrderWithSize(tablaCarrito, col,
                c -> Toast.mostrar(stage, "Para cambiar el asiento " + c.getNroAsiento()
                        + ", quítalo y elige otro en el croquis.", Toast.INFO),
                this::quitarDelCarrito);
        tablaCarrito.setPlaceholder(new Label("Tu carrito está vacío"));
        tablaCarrito.setPrefHeight(180);

        // Totales: el precio ya incluye IGV, se separa la base imponible
        lblBase = new Label();
        lblIgv = new Label();
        lblTotal = new Label();
        lblTotal.setFont(Font.font(18));
        lblTotal.getStyleClass().add("tarjeta-valor");
        VBox totales = new VBox(2, lblBase, lblIgv, lblTotal);
        totales.setAlignment(Pos.CENTER_RIGHT);

        cardCarrito.getChildren().addAll(tablaCarrito, totales);
        return cardCarrito;
    }

    private void listarCarrito() {
        tablaCarrito.getItems().clear();
        if (cliente != null) {
            tablaCarrito.getItems().addAll(carritoService.listaCarritoCliente(cliente.getDni()));
        }
        double total = redondear(tablaCarrito.getItems().stream().mapToDouble(VentaCarrito::getPrecio).sum());
        double base = redondear(total / (1 + IVentaPasajeService.TASA_IGV));
        lblBase.setText(String.format(Locale.US, "Base imponible: S/ %.2f", base));
        lblIgv.setText(String.format(Locale.US, "IGV (18 %%): S/ %.2f", redondear(total - base)));
        lblTotal.setText(String.format(Locale.US, "TOTAL: S/ %.2f", total));
        if (btnPagar != null) btnPagar.setDisable(tablaCarrito.getItems().isEmpty());
    }

    private void quitarDelCarrito(VentaCarrito item) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION,
                "¿Quitar el asiento " + item.getNroAsiento() + " de tu carrito?", ButtonType.YES, ButtonType.NO);
        alert.setHeaderText(null);
        alert.setTitle("Quitar asiento");
        if (alert.showAndWait().orElse(ButtonType.NO) != ButtonType.YES) return;
        try {
            carritoService.delete(item.getIdCarrito());
            Toast.mostrar(stage, "Asiento " + item.getNroAsiento() + " liberado", Toast.EXITO);
        } catch (Exception e) {
            Toast.mostrar(stage, "La reserva ya venció", Toast.AVISO);
        }
        listarCarrito();
        listarViajes();
        dibujarMapa();
    }

    // ---------------------------- PASO 5 ----------------------------
    private VBox crearPasoPago() {
        cardPago = tarjeta("5. Paga y recibe tu comprobante");

        cbxComprobante = new ComboBox<>(FXCollections.observableArrayList(TipoComprobante.values()));
        cbxComprobante.getSelectionModel().select(TipoComprobante.BOLETA);
        txtRuc = new TextField();
        txtRuc.setPromptText("RUC (11 dígitos)");
        txtRazon = new TextField();
        txtRazon.setPromptText("Razón social");
        // Los campos del RUC solo se ven si elige Factura
        VBox datosFactura = new VBox(6, txtRuc, txtRazon);
        datosFactura.visibleProperty().bind(cbxComprobante.valueProperty().isEqualTo(TipoComprobante.FACTURA));
        datosFactura.managedProperty().bind(datosFactura.visibleProperty());
        cbxComprobante.setOnAction(e -> proponerRuc());
        // Al completar los 11 dígitos del RUC se busca la razón social automáticamente
        txtRuc.textProperty().addListener((o, viejo, nuevo) -> {
            if (nuevo != null && !nuevo.matches("\\d{0,11}")) {
                txtRuc.setText(viejo);
                return;
            }
            if (nuevo != null && nuevo.length() == 11) buscarRuc(nuevo);
        });

        // El cliente paga solo con medios digitales (no hay caja para efectivo)
        cbxMetodo = new ComboBox<>(FXCollections.observableArrayList(
                MetodoPago.YAPE, MetodoPago.PLIN, MetodoPago.TARJETA, MetodoPago.TRANSFERENCIA));
        cbxMetodo.getSelectionModel().select(MetodoPago.YAPE);
        txtOperacion = new TextField();
        txtOperacion.setPromptText("N° de operación del pago");
        Label ayuda = new Label("Yapea o plinea al 987 654 321 (Jesús te guía a la UPeU) y escribe el N° de operación.");
        ayuda.setWrapText(true);
        ayuda.getStyleClass().add("tarjeta-nota");

        btnPagar = new Button("Pagar y emitir comprobante");
        btnPagar.getStyleClass().add("btn-principal");
        btnPagar.setMaxWidth(Double.MAX_VALUE);
        btnPagar.setDisable(true);
        btnPagar.setOnAction(e -> pagar());

        GridPane grid = new GridPane();
        grid.setHgap(8);
        grid.setVgap(8);
        grid.addRow(0, new Label("Comprobante"), cbxComprobante);
        grid.addRow(1, new Label("Forma de pago"), cbxMetodo);
        grid.addRow(2, new Label("N° operación"), txtOperacion);

        cardPago.getChildren().addAll(grid, datosFactura, ayuda, btnPagar);
        return cardPago;
    }

    /** Al elegir Factura se propone el RUC 10 del propio cliente (generado con su DNI). */
    private void proponerRuc() {
        if (cbxComprobante.getValue() == TipoComprobante.FACTURA && cliente != null
                && (txtRuc.getText() == null || txtRuc.getText().isBlank())) {
            txtRuc.setText(ventaService.rucDeDni(cliente.getDni()));
        }
    }

    /** Busca la razón social: primero en la BD (rápido) y si no, en SUNAT por internet. */
    private void buscarRuc(String ruc) {
        if (!ventaService.rucValido(ruc)) {
            Toast.mostrar(stage, "RUC no válido: revisa los 11 dígitos", Toast.AVISO);
            return;
        }
        Optional<String> conocida = ventaService.buscarRazonSocial(ruc);
        if (conocida.isPresent()) {
            txtRazon.setText(conocida.get());
            return;
        }
        txtRazon.setPromptText("Consultando SUNAT...");
        Task<ConsultaRUC.EmpresaDto> tarea = new Task<>() {
            @Override
            protected ConsultaRUC.EmpresaDto call() {
                return consultaRUC.consultarRUC(ruc);
            }
        };
        tarea.setOnSucceeded(ev -> {
            txtRazon.setPromptText("Razón social");
            ConsultaRUC.EmpresaDto e = tarea.getValue();
            if (e != null && ruc.equals(txtRuc.getText())) {
                txtRazon.setText(e.razonSocial());
                Toast.mostrar(stage, "SUNAT: " + e.razonSocial() + (e.situacion().isBlank() ? "" : " (" + e.situacion() + ")"), Toast.EXITO);
            } else if (e == null) {
                Toast.mostrar(stage, "No se encontró el RUC. Escribe la razón social.", Toast.AVISO);
            }
        });
        tarea.setOnFailed(ev -> txtRazon.setPromptText("Razón social"));
        Thread hilo = new Thread(tarea, "panel-cliente-ruc");
        hilo.setDaemon(true);
        hilo.start();
    }

    /** Valida el pago, registra la venta y muestra la boleta o factura. */
    private void pagar() {
        if (cliente == null || tablaCarrito.getItems().isEmpty()) {
            Toast.mostrar(stage, "Tu carrito está vacío", Toast.AVISO);
            return;
        }
        TipoComprobante tipo = cbxComprobante.getValue();
        MetodoPago metodo = cbxMetodo.getValue();
        String operacion = txtOperacion.getText() == null ? "" : txtOperacion.getText().trim();
        String ruc = txtRuc.getText() == null ? "" : txtRuc.getText().trim();
        String razon = txtRazon.getText() == null ? "" : txtRazon.getText().trim();
        // VALIDACIONES del pago
        if (!operacion.matches("[A-Za-z0-9-]{4,30}")) {
            Toast.mostrar(stage, "Escribe el N° de operación de " + metodo, Toast.AVISO);
            txtOperacion.requestFocus();
            return;
        }
        if (tipo == TipoComprobante.FACTURA) {
            if (!ventaService.rucValido(ruc)) {
                Toast.mostrar(stage, "RUC no válido para la factura", Toast.AVISO);
                txtRuc.requestFocus();
                return;
            }
            if (razon.isEmpty()) {
                Toast.mostrar(stage, "Escribe la razón social", Toast.AVISO);
                txtRazon.requestFocus();
                return;
            }
        }
        double total = redondear(tablaCarrito.getItems().stream().mapToDouble(VentaCarrito::getPrecio).sum());
        DatosPago pago = DatosPago.builder()
                .tipoComprobante(tipo)
                .ruc(ruc)
                .razonSocial(razon)
                .metodoPago(metodo)
                .nroOperacion(operacion)
                .montoRecibido(total)
                .build();
        try {
            // Misma venta que hace el taxista (una sola transacción), sin descuento
            VentaPasaje venta = ventaService.registrarVenta(cliente.getDni(), ID_USUARIO_AUTOSERVICIO, 0, pago);
            mostrarComprobante(venta);
            txtOperacion.clear();
            cbxComprobante.getSelectionModel().select(TipoComprobante.BOLETA);
            txtRuc.clear();
            txtRazon.clear();
        } catch (Exception e) {
            Toast.mostrar(stage, "No se registró la compra: " + e.getMessage(), Toast.ERROR);
        }
        listarCarrito();
        listarViajes();
        dibujarMapa();
    }

    /** Muestra la boleta o factura generada (mismo texto que la venta del taxista). */
    private void mostrarComprobante(VentaPasaje venta) {
        pe.edu.upeu.syspasajes.utils.AvisoTaxista.enviarAutomatico(venta);   // WhatsApp al taxista con la reserva y el pago
        pe.edu.upeu.syspasajes.components.DialogoComprobante.mostrar(venta, ventaService.generarTextoBoleta(venta),
                "¡Compra realizada!", (venta.esFactura() ? "Factura " : "Boleta ") + venta.getSerie() + "-"
                        + venta.getNumDoc() + "  ·  ¡Buen viaje!", stage);
    }

    private static double redondear(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}
