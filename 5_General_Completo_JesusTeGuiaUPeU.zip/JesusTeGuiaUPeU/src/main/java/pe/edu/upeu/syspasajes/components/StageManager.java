/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : StageManager.java                                            │
 * │ CAPA    : Componente visual                                            │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Recuerda la ventana principal para mostrar avisos y cambiar de       │
 * │   pantalla.                                                            │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.components;

import javafx.stage.Stage;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;


public class StageManager {
    private static Stage primaryStage;

    public static void setPrimaryStage(Stage stage) {
        primaryStage = stage;
    }

    public static Stage getPrimaryStage() {
        return primaryStage;
    }

}

