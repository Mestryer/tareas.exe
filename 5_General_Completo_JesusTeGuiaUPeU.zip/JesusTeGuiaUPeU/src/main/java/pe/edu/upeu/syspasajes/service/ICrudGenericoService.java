/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ICrudGenericoService.java                                    │
 * │ CAPA    : Servicio (interfaz)                                          │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Contrato del CRUD genérico de los servicios.                         │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service;

import java.util.List;

public interface ICrudGenericoService<T, ID> {
    T save(T t);
    T update(ID id, T t);
    List<T> findAll();
    T findById(ID id);
    void delete(ID id);
}
