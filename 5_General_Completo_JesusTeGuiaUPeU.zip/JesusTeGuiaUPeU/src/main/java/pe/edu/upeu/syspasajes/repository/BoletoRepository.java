/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : BoletoRepository.java                                        │
 * │ CAPA    : Repositorio (base de datos)                                  │
 * │ MÓDULO  : Venta                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Lee los boletos (asientos vendidos) de una venta.                    │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import pe.edu.upeu.syspasajes.model.Boleto;
import pe.edu.upeu.syspasajes.model.VentaPasaje;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class BoletoRepository extends AbstractJpaRepository<Boleto, Long> {

    @Override protected String getTableName() { return "boleto"; }
    @Override protected String getPkColumn()  { return "id_boleto"; }

    private static final String SELECT_JOIN =
            "SELECT b.id_boleto, b.id_venta, b.nro_asiento, b.precio, " +
            ViajeRepository.VIAJE_COLS +
            "FROM boleto b " +
            "JOIN viaje vi ON b.id_viaje = vi.id_viaje " +
            ViajeRepository.JOIN_VEHICULO;

    @Override
    public List<Boleto> findAll() {
        return executeQuery(SELECT_JOIN + "ORDER BY b.id_boleto");
    }

    @Override
    public Optional<Boleto> findById(Long id) {
        return executeQueryOne(SELECT_JOIN + "WHERE b.id_boleto = ?", id);
    }

    public List<Boleto> listarPorVenta(Long idVenta) {
        return executeQuery(SELECT_JOIN + "WHERE b.id_venta = ? ORDER BY vi.fecha, vi.hora_salida, b.nro_asiento", idVenta);
    }

    @Override
    protected Boleto mapRow(ResultSet rs) throws SQLException {
        VentaPasaje v = new VentaPasaje();
        v.setId(rs.getLong("id_venta"));
        return Boleto.builder()
                .idBoleto(rs.getLong("id_boleto"))
                .venta(v)
                .nroAsiento(rs.getInt("nro_asiento"))
                .precio(rs.getDouble("precio"))
                .viaje(ViajeRepository.mapViaje(rs, false))
                .build();
    }

    @Override
    protected Boleto insert(Connection conn, Boleto e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO boleto(id_venta,id_viaje,nro_asiento,precio) VALUES(?,?,?,?)",
                e.getVenta().getId(), e.getViaje().getIdViaje(), e.getNroAsiento(), e.getPrecio());
        e.setIdBoleto(id);
        return e;
    }

    @Override
    protected Boleto updateRow(Connection conn, Boleto e) throws SQLException {
        executeUpdate(conn,
                "UPDATE boleto SET id_venta=?,id_viaje=?,nro_asiento=?,precio=? WHERE id_boleto=?",
                e.getVenta().getId(), e.getViaje().getIdViaje(), e.getNroAsiento(), e.getPrecio(), e.getIdBoleto());
        return e;
    }
}
