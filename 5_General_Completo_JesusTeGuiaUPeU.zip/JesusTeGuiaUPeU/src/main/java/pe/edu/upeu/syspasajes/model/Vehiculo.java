/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Vehiculo.java                                                │
 * │ CAPA    : Modelo (datos)                                               │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Vehículo de la flota con su marca, modelo, color, asientos y el      │
 * │   taxista que lo maneja.                                               │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;

/** Unidad de la flota (taxi o combi) con su conductor y su marca. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Vehiculo {

    private Long idVehiculo;

    @NotBlank(message = "La placa es obligatoria")
    @Pattern(regexp = "^[A-Z0-9]{3}-[A-Z0-9]{3}$", message = "La placa debe tener el formato ABC-123")
    private String placa;

    @NotNull(message = "El tipo de vehículo es obligatorio")
    private TipoVehiculo tipoVehiculo;

    @NotNull(message = "Debe elegir la marca")
    private Marca marca;

    @NotBlank(message = "El modelo es obligatorio")
    @Size(max = 30, message = "El modelo admite máximo 30 caracteres")
    private String modelo;

    @NotBlank(message = "El nombre del conductor es obligatorio")
    @Size(max = 60, message = "El conductor admite máximo 60 caracteres")
    private String conductor;

    @Pattern(regexp = "^9\\d{8}$", message = "El celular del conductor debe tener 9 dígitos y empezar con 9")
    private String telefonoConductor;

    @NotBlank(message = "El color es obligatorio")
    @Size(max = 20, message = "El color admite máximo 20 caracteres")
    private String color;

    /** Se deduce del tipo: taxi = 4, combi = 10. */
    private Integer asientos;

    @NotBlank(message = "El estado es obligatorio")
    private String estado;

    public String getTipoTexto() {
        return tipoVehiculo == null ? "" : tipoVehiculo.getDescripcion();
    }

    public String getMarcaNombre() {
        return marca == null || marca.getNombre() == null ? "" : marca.getNombre();
    }

    /** "Toyota Yaris" (marca + modelo). */
    public String getMarcaModelo() {
        String m = getMarcaNombre();
        String mod = modelo == null ? "" : modelo;
        return (m + " " + mod).trim();
    }

    public String getTelefonoTexto() {
        return telefonoConductor == null ? "" : telefonoConductor;
    }

    /** Texto para combos: "Taxi ABC-123 - Juan Pérez". */
    public String getDescripcionCorta() {
        return getTipoTexto() + " " + placa + " - " + conductor;
    }
}
