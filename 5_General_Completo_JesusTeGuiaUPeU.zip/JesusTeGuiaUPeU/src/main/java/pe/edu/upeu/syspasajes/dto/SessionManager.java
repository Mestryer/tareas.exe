/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : SessionManager.java                                          │
 * │ CAPA    : DTO                                                          │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Guarda quién inició sesión (id, usuario y perfil) mientras el        │
 * │   sistema está abierto.                                                │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.dto;

import lombok.Data;

/** Guarda los datos del usuario que inició sesión (Singleton). */
@Data
public class SessionManager {
    static SessionManager instance;
    Long userId;
    String userName;
    String userPerfil;

    public static synchronized SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public void cerrarSesion() {
        userId = null;
        userName = null;
        userPerfil = null;
    }
}
