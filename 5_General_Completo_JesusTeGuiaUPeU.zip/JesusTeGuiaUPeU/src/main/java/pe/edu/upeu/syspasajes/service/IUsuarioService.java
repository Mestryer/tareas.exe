/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : IUsuarioService.java                                         │
 * │ CAPA    : Servicio (interfaz)                                          │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Inicio de sesión de usuarios.                                        │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service;

import pe.edu.upeu.syspasajes.model.Usuario;

import java.util.Optional;

public interface IUsuarioService extends ICrudGenericoService<Usuario, Long> {
    Optional<Usuario> loginUsuario(String usuario, String clave);
}
