/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : IVehiculoService.java                                        │
 * │ CAPA    : Servicio (interfaz)                                          │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Qué se puede hacer con vehículos: CRUD, activos y búsqueda por       │
 * │   placa.                                                               │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service;

import pe.edu.upeu.syspasajes.dto.ComboBoxOption;
import pe.edu.upeu.syspasajes.model.Vehiculo;

import java.util.List;
import java.util.Optional;

public interface IVehiculoService extends ICrudGenericoService<Vehiculo, Long> {
    List<ComboBoxOption> listarTipoVehiculo();
    List<ComboBoxOption> listarCombobox();
    List<Vehiculo> listarActivos();
    Optional<Vehiculo> buscarPorPlaca(String placa);
}
