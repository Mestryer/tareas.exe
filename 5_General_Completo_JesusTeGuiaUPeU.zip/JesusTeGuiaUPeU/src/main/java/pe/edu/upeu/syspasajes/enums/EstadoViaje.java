/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : EstadoViaje.java                                             │
 * │ CAPA    : Enumeración                                                  │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Estados de una salida: programado, en ruta, finalizado o             │
 * │   cancelado.                                                           │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.enums;

import lombok.Getter;

@Getter
public enum EstadoViaje {
    PROGRAMADO("Programado"),
    EN_RUTA("En ruta"),
    FINALIZADO("Finalizado"),
    CANCELADO("Cancelado");

    private final String descripcion;

    EstadoViaje(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
