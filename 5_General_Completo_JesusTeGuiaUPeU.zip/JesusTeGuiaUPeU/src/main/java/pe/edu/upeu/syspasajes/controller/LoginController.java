/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : LoginController.java                                         │
 * │ CAPA    : Controlador (pantalla)                                       │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Ingreso con usuario y contraseña (administrador o taxista) y         │
 * │   animación del candado.                                               │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import javafx.animation.PauseTransition;
import javafx.animation.TranslateTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.util.Duration;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.syspasajes.components.StageManager;
import pe.edu.upeu.syspasajes.components.Toast;
import pe.edu.upeu.syspasajes.config.AppContext;
import pe.edu.upeu.syspasajes.config.DatabaseConfig;
import pe.edu.upeu.syspasajes.dto.SessionManager;
import pe.edu.upeu.syspasajes.model.Usuario;
import pe.edu.upeu.syspasajes.service.IUsuarioService;

import java.util.Objects;

@RequiredArgsConstructor
public class LoginController {

    private final IUsuarioService u;

    @FXML TextField usuario;
    @FXML PasswordField clave;
    @FXML ImageView imgCandado;
    @FXML Label lblEstado;
    @FXML Button btnIngresar;

    private Image candadoCerrado;
    private Image candadoAbierto;

    @FXML
    public void initialize() {
        candadoCerrado = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/img/candado_taxi_cerrado.png")));
        candadoAbierto = new Image(Objects.requireNonNull(getClass().getResourceAsStream("/img/candado_taxi_abierto.png")));
        imgCandado.setImage(candadoCerrado);
        lblEstado.setText("");
        btnIngresar.setDisable(false);
        Platform.runLater(() -> usuario.requestFocus());
    }

    @FXML
    public void login(ActionEvent e) {
        String user = usuario.getText() == null ? "" : usuario.getText().trim();
        String pass = clave.getText() == null ? "" : clave.getText();
        if (user.isEmpty() || pass.isEmpty()) {
            mensajeError(e, "Ingrese su usuario y contraseña");
            return;
        }
        try {
            u.loginUsuario(user, pass)
                    .filter(usu -> "ACTIVO".equalsIgnoreCase(usu.getEstado()))
                    .ifPresentOrElse(
                            usu -> abrirCandado(e, usu),
                            () -> mensajeError(e, "Credenciales incorrectas... intente nuevamente!!"));
        } catch (Exception ex) {
            mensajeError(e, "Error al conectar con la base de datos: " + ex.getMessage());
        }
    }

    /** Animación: el candado se abre y luego entra al sistema. */
    private void abrirCandado(ActionEvent e, Usuario usu) {
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        btnIngresar.setDisable(true);
        imgCandado.setImage(candadoAbierto);
        lblEstado.setStyle("-fx-text-fill: #1553c7;");
        lblEstado.setText("¡Bienvenido " + usu.getUsuario() + "! Abriendo...");
        PauseTransition pausa = new PauseTransition(Duration.millis(700));
        pausa.setOnFinished(ev -> abrirMain(stage, usu));
        pausa.play();
    }

    public void mensajeError(ActionEvent e, String msg) {
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        lblEstado.setStyle("-fx-text-fill: #c62828;");
        lblEstado.setText(msg);
        // Sacudida del candado
        TranslateTransition tt = new TranslateTransition(Duration.millis(60), imgCandado);
        tt.setFromX(0);
        tt.setByX(10);
        tt.setCycleCount(6);
        tt.setAutoReverse(true);
        tt.setOnFinished(ev -> imgCandado.setTranslateX(0));
        tt.play();
        double w = stage.getX() + stage.getWidth() / 2 - 160, h = stage.getY() + stage.getHeight() - 120;
        Toast.showToast(stage, msg, Toast.ERROR, 2000, w, h);
        clave.clear();
        clave.requestFocus();
    }

    private void abrirMain(Stage stage, Usuario usu) {
        try {
            SessionManager.getInstance().setUserId(usu.getIdUsuario());
            SessionManager.getInstance().setUserName(usu.getUsuario());
            SessionManager.getInstance().setUserPerfil(usu.getIdPerfil().getNombre());

            AppContext context = AppContext.getInstance();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/view/maingui.fxml"));
            fxmlLoader.setControllerFactory(context::getBean);
            Rectangle2D r2d = Screen.getPrimary().getVisualBounds();
            Scene scene = new Scene(fxmlLoader.load(), r2d.getWidth(), r2d.getHeight() - 50);
            // El tema de color se aplica en MainguiController (recuerda el último elegido)
            MainguiController.aplicarTemaGuardado(scene);

            stage.setTitle("Jesús te guía a la UPeU | " + usu.getIdPerfil().getNombre() + ": " + usu.getUsuario());
            stage.setResizable(true);
            stage.setScene(scene);
            stage.setX(r2d.getMinX());
            stage.setY(r2d.getMinY());
            StageManager.setPrimaryStage(stage);
            stage.setWidth(r2d.getWidth());
            stage.setHeight(r2d.getHeight());
            stage.show();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    /** Botón "Soy cliente": abre el panel donde el cliente compra su propio pasaje (sin contraseña). */
    @FXML
    public void abrirPanelCliente(ActionEvent e) {
        Stage stage = (Stage) ((Node) e.getSource()).getScene().getWindow();
        AppContext.getInstance().getBean(PanelClienteController.class).mostrar(stage);
    }

    @FXML
    public void logout(ActionEvent e) {
        DatabaseConfig.shutdown();
        Platform.exit();
        System.exit(0);
    }
}
