/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : TipoTab.java                                                 │
 * │ CAPA    : Enumeración                                                  │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Indica si una pantalla se abre dentro de una pestaña o aparte.       │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.enums;

public enum TipoTab {
    INTERNO,
    EXTERNO
}
