/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ColumnInfo.java                                              │
 * │ CAPA    : Componente visual                                            │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Guarda el nombre del campo y el ancho de una columna para armar      │
 * │   las tablas.                                                          │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.components;

public class ColumnInfo {
    private String field;  // El nombre del campo en el modelo
    private Double width;  // El ancho deseado para la columna

    public ColumnInfo(String field, Double width) {
        this.field = field;
        this.width = width;
    }

    public String getField() {
        return field;
    }

    public Double getWidth() {
        return width;
    }
}
