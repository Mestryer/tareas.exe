/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Acceso.java                                                  │
 * │ CAPA    : Modelo (datos)                                               │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Permiso de menú asociado a un perfil.                                │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

import lombok.Getter;
import lombok.Setter;
import pe.edu.upeu.syspasajes.enums.Menus;
import pe.edu.upeu.syspasajes.enums.TipoTab;

@Getter
@Setter
public class Acceso {
    String idAcceso;
    String urlAcceso;
    String menuItemNombre;
    Menus menuNombre;
    TipoTab nombreTab;
}
