/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VehiculoController.java                                      │
 * │ CAPA    : Controlador (pantalla)                                       │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Pantalla Vehículos y conductores: placa, tipo (taxi 4 / van 10),     │
 * │   marca, modelo y datos del taxista; todo se puede modificar.          │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import lombok.RequiredArgsConstructor;
import pe.edu.upeu.syspasajes.components.ColumnInfo;
import pe.edu.upeu.syspasajes.components.TableViewHelper;
import pe.edu.upeu.syspasajes.components.Toast;
import pe.edu.upeu.syspasajes.components.ToltipCustom;
import pe.edu.upeu.syspasajes.dto.ComboBoxOption;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Marca;
import pe.edu.upeu.syspasajes.model.Vehiculo;
import pe.edu.upeu.syspasajes.service.IMarcaService;
import pe.edu.upeu.syspasajes.service.IVehiculoService;

import java.util.*;
import java.util.function.Consumer;

/** CRUD de la flota y sus conductores (cada vehículo tiene su conductor y su marca). */
@RequiredArgsConstructor
public class VehiculoController {

    private final IVehiculoService vs;
    private final IMarcaService ms;

    @FXML ComboBox<ComboBoxOption> cbxTipoVehiculo;
    @FXML ComboBox<String> cbxEstado;
    @FXML ComboBox<Marca> cbxMarca;
    @FXML TextField txtPlaca, txtModelo, txtConductor, txtTelefono, txtColor, txtAsientos, txtFiltroDato;
    @FXML Label lbnMsg;
    @FXML Button btnGuardar;
    @FXML private TableView<Vehiculo> tableView;
    @FXML private AnchorPane miContenedor;

    private Validator validator;
    private final ToltipCustom ttc = new ToltipCustom();
    private List<Vehiculo> listaVehiculos = new ArrayList<>();
    private Vehiculo formulario;
    private Long idVehiculoCE = 0L;

    @FXML
    public void initialize() {
        idVehiculoCE = 0L;
        cbxTipoVehiculo.getItems().setAll(vs.listarTipoVehiculo());
        cbxMarca.getItems().setAll(ms.listarActivas());
        cbxMarca.setOnShowing(e -> recargarMarcas());
        cbxEstado.getItems().setAll("ACTIVO", "INACTIVO");
        cbxEstado.getSelectionModel().select("ACTIVO");
        txtAsientos.setEditable(false);
        // Al elegir el tipo se muestran los asientos: taxi 4, combi 10
        cbxTipoVehiculo.setOnAction(e -> {
            ComboBoxOption op = cbxTipoVehiculo.getSelectionModel().getSelectedItem();
            txtAsientos.setText(op == null ? "" : String.valueOf(TipoVehiculo.valueOf(op.getKey()).getAsientos()));
        });
        // Placa siempre en mayúsculas
        txtPlaca.textProperty().addListener((obs, viejo, nuevo) -> {
            if (nuevo != null && !nuevo.equals(nuevo.toUpperCase())) txtPlaca.setText(nuevo.toUpperCase());
        });
        txtFiltroDato.textProperty().addListener((obs, v, n) -> filtrar());

        validator = Validation.buildDefaultValidatorFactory().getValidator();

        TableViewHelper<Vehiculo> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("ID", new ColumnInfo("idVehiculo", 50.0));
        columns.put("Placa", new ColumnInfo("placa", 90.0));
        columns.put("Tipo", new ColumnInfo("tipoTexto", 80.0));
        columns.put("Asientos", new ColumnInfo("asientos", 75.0));
        columns.put("Marca / Modelo", new ColumnInfo("marcaModelo", 150.0));
        columns.put("Conductor", new ColumnInfo("conductor", 190.0));
        columns.put("Celular", new ColumnInfo("telefonoTexto", 95.0));
        columns.put("Color", new ColumnInfo("color", 90.0));
        columns.put("Estado", new ColumnInfo("estado", 85.0));

        Consumer<Vehiculo> updateAction = this::editForm;
        Consumer<Vehiculo> deleteAction = v -> {
            if (!confirmar("¿Eliminar el vehículo " + v.getPlaca() + "?")) return;
            try {
                vs.delete(v.getIdVehiculo());
                Toast.mostrar(stage(), "Vehículo eliminado correctamente", Toast.EXITO);
                if (Objects.equals(idVehiculoCE, v.getIdVehiculo())) clearForm();
            } catch (Exception ex) {
                Toast.mostrar(stage(), "No se puede eliminar: el vehículo tiene salidas programadas. "
                        + "Puede marcarlo como INACTIVO.", Toast.ERROR);
            }
            listar();
        };
        helper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        tableView.setTableMenuButtonVisible(true);
        lbnMsg.setText("");
        listar();
    }

    public void listar() {
        listaVehiculos = vs.findAll();
        filtrar();
    }

    private void filtrar() {
        String f = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        tableView.setItems(FXCollections.observableArrayList(listaVehiculos.stream()
                .filter(v -> f.isEmpty()
                        || v.getPlaca().toLowerCase().contains(f)
                        || v.getConductor().toLowerCase().contains(f)
                        || v.getTipoTexto().toLowerCase().contains(f)
                        || v.getMarcaModelo().toLowerCase().contains(f))
                .toList()));
    }

    @FXML
    public void validarFormulario() {
        formulario = new Vehiculo();
        formulario.setPlaca(txtPlaca.getText() == null ? "" : txtPlaca.getText().trim().toUpperCase());
        formulario.setMarca(cbxMarca.getSelectionModel().getSelectedItem());
        formulario.setModelo(txt(txtModelo));
        formulario.setConductor(txt(txtConductor));
        String tel = txt(txtTelefono);
        formulario.setTelefonoConductor(tel.isEmpty() ? null : tel);
        formulario.setColor(txt(txtColor));
        formulario.setEstado(cbxEstado.getSelectionModel().getSelectedItem());
        ComboBoxOption tipo = cbxTipoVehiculo.getSelectionModel().getSelectedItem();
        formulario.setTipoVehiculo(tipo == null ? null : TipoVehiculo.valueOf(tipo.getKey()));
        if (formulario.getTipoVehiculo() != null) {
            formulario.setAsientos(formulario.getTipoVehiculo().getAsientos());
        }

        List<ConstraintViolation<Vehiculo>> violaciones = validator.validate(formulario).stream()
                .sorted(Comparator.comparing(v -> v.getPropertyPath().toString())).toList();
        if (!violaciones.isEmpty()) {
            mostrarErroresValidacion(violaciones);
            return;
        }
        // Regla de negocio: la placa no se puede repetir
        Optional<Vehiculo> mismaPlaca = vs.buscarPorPlaca(formulario.getPlaca());
        if (mismaPlaca.isPresent() && !mismaPlaca.get().getIdVehiculo().equals(idVehiculoCE)) {
            limpiarError();
            ttc.marcarError(txtPlaca, "Ya existe un vehículo con la placa " + formulario.getPlaca());
            lbnMsg.setText("Ya existe un vehículo con la placa " + formulario.getPlaca());
            lbnMsg.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 14px;");
            return;
        }
        procesarFormulario();
    }

    private void mostrarErroresValidacion(List<ConstraintViolation<Vehiculo>> violaciones) {
        limpiarError();
        Map<String, Control> campos = new LinkedHashMap<>();
        campos.put("placa", txtPlaca);
        campos.put("tipoVehiculo", cbxTipoVehiculo);
        campos.put("marca", cbxMarca);
        campos.put("modelo", txtModelo);
        campos.put("conductor", txtConductor);
        campos.put("telefonoConductor", txtTelefono);
        campos.put("color", txtColor);
        campos.put("estado", cbxEstado);

        String primerMensaje = null;
        Control primerCtrl = null;
        for (Map.Entry<String, Control> campo : campos.entrySet()) {
            Optional<ConstraintViolation<Vehiculo>> v = violaciones.stream()
                    .filter(x -> x.getPropertyPath().toString().equals(campo.getKey())).findFirst();
            if (v.isPresent()) {
                ttc.marcarError(campo.getValue(), v.get().getMessage());
                if (primerMensaje == null) {
                    primerMensaje = v.get().getMessage();
                    primerCtrl = campo.getValue();
                }
            }
        }
        if (primerMensaje != null) {
            lbnMsg.setText(primerMensaje);
            lbnMsg.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 14px;");
            Control foco = primerCtrl;
            Platform.runLater(foco::requestFocus);
        }
    }

    private void procesarFormulario() {
        try {
            if (idVehiculoCE > 0L) {
                formulario.setIdVehiculo(idVehiculoCE);
                vs.update(idVehiculoCE, formulario);
                Toast.mostrar(stage(), "Vehículo actualizado correctamente", Toast.EXITO);
            } else {
                vs.save(formulario);
                Toast.mostrar(stage(), "Vehículo registrado correctamente", Toast.EXITO);
            }
            clearForm();
            lbnMsg.setText("Formulario guardado");
            lbnMsg.setStyle("-fx-text-fill: #1553c7; -fx-font-size: 14px;");
            listar();
        } catch (Exception ex) {
            lbnMsg.setText("Error al guardar: " + ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 14px;");
        }
    }

    public void editForm(Vehiculo v) {
        limpiarError();
        idVehiculoCE = v.getIdVehiculo();
        txtPlaca.setText(v.getPlaca());
        recargarMarcas();
        cbxMarca.getSelectionModel().select(cbxMarca.getItems().stream()
                .filter(m -> v.getMarca() != null && Objects.equals(m.getIdMarca(), v.getMarca().getIdMarca()))
                .findFirst().orElse(null));
        txtModelo.setText(v.getModelo());
        txtConductor.setText(v.getConductor());
        txtTelefono.setText(v.getTelefonoTexto());
        txtColor.setText(v.getColor());
        txtAsientos.setText(String.valueOf(v.getAsientos()));
        cbxEstado.getSelectionModel().select(v.getEstado());
        cbxTipoVehiculo.getSelectionModel().select(cbxTipoVehiculo.getItems().stream()
                .filter(o -> o.getKey().equals(v.getTipoVehiculo().name()))
                .findFirst().orElse(null));
        btnGuardar.setText("Actualizar");
        lbnMsg.setText("Editando vehículo " + v.getPlaca());
        lbnMsg.setStyle("-fx-text-fill: #1565c0; -fx-font-size: 14px;");
    }

    @FXML
    public void clearForm() {
        txtPlaca.clear();
        cbxMarca.getSelectionModel().clearSelection();
        txtModelo.clear();
        txtConductor.clear();
        txtTelefono.clear();
        txtColor.clear();
        txtAsientos.clear();
        cbxTipoVehiculo.getSelectionModel().clearSelection();
        cbxEstado.getSelectionModel().select("ACTIVO");
        idVehiculoCE = 0L;
        btnGuardar.setText("Guardar");
        lbnMsg.setText("");
        limpiarError();
    }

    public void limpiarError() {
        List.of(txtPlaca, cbxTipoVehiculo, cbxMarca, txtModelo, txtConductor, txtTelefono, txtColor, cbxEstado)
                .forEach(ttc::limpiarCampo);
    }

    /** Vuelve a leer las marcas activas (por si se agregaron en el módulo Marca). */
    private void recargarMarcas() {
        Marca sel = cbxMarca.getSelectionModel().getSelectedItem();
        List<Marca> marcas = new ArrayList<>(ms.listarActivas());
        // Si el vehículo editado tiene una marca INACTIVA se agrega para no perderla
        if (sel != null && marcas.stream().noneMatch(m -> Objects.equals(m.getIdMarca(), sel.getIdMarca()))) {
            marcas.add(sel);
        }
        cbxMarca.getItems().setAll(marcas);
        if (sel != null) {
            marcas.stream().filter(m -> Objects.equals(m.getIdMarca(), sel.getIdMarca())).findFirst()
                    .ifPresent(m -> cbxMarca.getSelectionModel().select(m));
        }
    }

    private String txt(TextField tf) {
        return tf.getText() == null ? "" : tf.getText().trim();
    }

    private boolean confirmar(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, mensaje, ButtonType.OK, ButtonType.CANCEL);
        alert.setTitle("Confirmación");
        alert.setHeaderText(null);
        return alert.showAndWait().filter(b -> b == ButtonType.OK).isPresent();
    }

    private Stage stage() {
        return (Stage) miContenedor.getScene().getWindow();
    }
}
