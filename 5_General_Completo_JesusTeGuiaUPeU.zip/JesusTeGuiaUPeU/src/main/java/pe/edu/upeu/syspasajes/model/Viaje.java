/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Viaje.java                                                   │
 * │ CAPA    : Modelo (datos)                                               │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Salida programada: vehículo, sentido, fecha, hora, precio y          │
 * │   asientos libres.                                                     │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.syspasajes.enums.EstadoViaje;
import pe.edu.upeu.syspasajes.enums.Sentido;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/** Salida programada de un vehículo en un sentido de la ruta. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Viaje {

    private Long idViaje;

    @NotNull(message = "Debe elegir el vehículo")
    private Vehiculo vehiculo;

    @NotNull(message = "Debe elegir el sentido de la ruta")
    private Sentido sentido;

    @NotNull(message = "La fecha es obligatoria")
    private LocalDate fecha;

    @NotNull(message = "La hora de salida es obligatoria (formato HH:mm)")
    private LocalTime horaSalida;

    @NotNull(message = "El precio es obligatorio")
    @Positive(message = "El precio debe ser mayor a cero")
    private Double precio;

    @NotNull(message = "El estado es obligatorio")
    private EstadoViaje estado;

    /** Asientos vendidos + reservados (dato calculado, no es columna). */
    private Integer asientosOcupados;

    public int getCapacidad() {
        return (vehiculo == null || vehiculo.getAsientos() == null) ? 0 : vehiculo.getAsientos();
    }

    public int getAsientosLibres() {
        int ocupados = asientosOcupados == null ? 0 : asientosOcupados;
        return Math.max(0, getCapacidad() - ocupados);
    }

    public String getLibresTexto() {
        return getAsientosLibres() + " / " + getCapacidad();
    }

    public String getHoraTexto() {
        return horaSalida == null ? "" : horaSalida.format(DateTimeFormatter.ofPattern("HH:mm"));
    }

    public String getFechaTexto() {
        return fecha == null ? "" : fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy"));
    }

    public String getRutaTexto() {
        return sentido == null ? "" : sentido.getDescripcion();
    }

    public String getPrecioTexto() {
        return String.format("S/ %.2f", precio == null ? 0.0 : precio);
    }

    public String getEstadoTexto() {
        return estado == null ? "" : estado.getDescripcion();
    }

    public String getPlaca() {
        return vehiculo == null ? "" : vehiculo.getPlaca();
    }

    public String getConductor() {
        return vehiculo == null ? "" : vehiculo.getConductor();
    }

    public String getTipoTexto() {
        return vehiculo == null ? "" : vehiculo.getTipoTexto();
    }

    /** true si la hora de salida ya pasó. */
    public boolean yaPartio() {
        if (fecha == null || horaSalida == null) return false;
        return LocalDateTime.of(fecha, horaSalida).isBefore(LocalDateTime.now());
    }
}
