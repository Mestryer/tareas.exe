/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ICrudGenericoRepository.java                                 │
 * │ CAPA    : Repositorio (interfaz)                                       │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Contrato de las operaciones básicas que tiene todo repositorio.      │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import java.util.List;
import java.util.Optional;

public interface ICrudGenericoRepository<T,ID> {
    T save(T entity);
    T update(T entity);
    Optional<T> findById(ID id);
    List<T> findAll();
    void deleteById(ID id);
    boolean existsById(ID id);
}
