/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : UsuarioServiceImp.java                                       │
 * │ CAPA    : Servicio (reglas)                                            │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Valida usuario y contraseña al iniciar sesión.                       │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import pe.edu.upeu.syspasajes.model.Usuario;
import pe.edu.upeu.syspasajes.repository.ICrudGenericoRepository;
import pe.edu.upeu.syspasajes.repository.UsuarioRepository;
import pe.edu.upeu.syspasajes.service.IUsuarioService;

import java.util.Optional;

public class UsuarioServiceImp extends CrudGenericoServiceImp<Usuario,Long> implements IUsuarioService {
    private final UsuarioRepository repo;

    public UsuarioServiceImp(UsuarioRepository repo) {
        this.repo = repo;
    }

    @Override
    protected ICrudGenericoRepository<Usuario, Long> getRepo() {
        return repo;
    }

    @Override
    public Optional<Usuario> loginUsuario(String usuario, String clave) {
        return repo.findByUsuarioAndClave(usuario, clave);
    }


}
