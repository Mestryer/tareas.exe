/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Toast.java                                                   │
 * │ CAPA    : Componente visual                                            │
 * │ MÓDULO  : General                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Muestra mensajes flotantes de éxito, aviso o error que desaparecen   │
 * │   solos.                                                               │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.components;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Toast {

    /** Colores predefinidos para los mensajes. */
    public static final String EXITO = "#9BE7A6";
    public static final String ERROR = "#FEA1B6";
    public static final String AVISO = "#FFE082";
    public static final String INFO  = "#9FD3FF";

    public static void showToast(Stage ownerStage, String message, String colorFondo, int durationInMillis, double x, double y) {
        showToastMain(ownerStage, message, colorFondo, durationInMillis, x, y);
    }

    public static void showToast(Stage ownerStage, String message, int durationInMillis, double x, double y) {
        showToastMain(ownerStage, message, "", durationInMillis, x, y);
    }

    /**
     * Muestra el mensaje centrado en la parte superior de la ventana.
     * (El ejemplo original usaba stage.getMaxWidth(), que vale Double.MAX_VALUE).
     */
    public static void mostrar(Stage ownerStage, String message, String colorFondo) {
        if (ownerStage == null) {
            System.out.println("[Toast] " + message);
            return;
        }
        double x = ownerStage.getX() + ownerStage.getWidth() / 2 - 180;
        double y = ownerStage.getY() + 70;
        showToastMain(ownerStage, message, colorFondo, 2500, x, y);
    }

    public static void showToastMain(Stage ownerStage, String message, String colorFondo, int durationInMillis, double x, double y) {
        if (colorFondo == null || colorFondo.isEmpty()) { colorFondo = "#00FF99"; }
        Label label = new Label(message);
        label.setWrapText(true);
        label.setMaxWidth(420);
        label.setStyle("-fx-background-color: " + colorFondo + "; -fx-text-fill: black; -fx-font-size: 13px; "
                + "-fx-padding: 10px 16px; -fx-border-radius: 8px; -fx-background-radius: 8px; "
                + "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.35), 10, 0, 0, 3);");
        label.setOpacity(0);
        Popup popup = new Popup();
        popup.setAutoFix(true);
        popup.setAutoHide(true);
        popup.setHideOnEscape(true);
        StackPane pane = new StackPane(label);
        pane.setPadding(new Insets(10));
        pane.setAlignment(Pos.CENTER);
        popup.getContent().add(pane);
        popup.show(ownerStage, x, y);
        Timeline fadeIn = new Timeline(new KeyFrame(Duration.millis(300), new KeyValue(label.opacityProperty(), 1)));
        Timeline fadeOut = new Timeline(new KeyFrame(Duration.millis(300), new KeyValue(label.opacityProperty(), 0)));
        Timeline delay = new Timeline(new KeyFrame(Duration.millis(durationInMillis)));
        delay.setOnFinished(event -> fadeOut.play());
        fadeIn.play();
        fadeIn.setOnFinished(event -> delay.play());
        fadeOut.setOnFinished(event -> popup.hide());
    }
}
