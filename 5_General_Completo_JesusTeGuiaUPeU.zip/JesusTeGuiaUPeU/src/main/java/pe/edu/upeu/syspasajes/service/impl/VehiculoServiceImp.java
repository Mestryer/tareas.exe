/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VehiculoServiceImp.java                                      │
 * │ CAPA    : Servicio (reglas)                                            │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Listas de vehículos y tipos para los ComboBox.                       │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.syspasajes.dto.ComboBoxOption;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Vehiculo;
import pe.edu.upeu.syspasajes.repository.ICrudGenericoRepository;
import pe.edu.upeu.syspasajes.repository.VehiculoRepository;
import pe.edu.upeu.syspasajes.service.IVehiculoService;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
public class VehiculoServiceImp extends CrudGenericoServiceImp<Vehiculo, Long> implements IVehiculoService {

    private final VehiculoRepository vehiculoRepository;

    @Override
    protected ICrudGenericoRepository<Vehiculo, Long> getRepo() {
        return vehiculoRepository;
    }

    @Override
    public List<ComboBoxOption> listarTipoVehiculo() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (TipoVehiculo tv : TipoVehiculo.values()) {
            listar.add(new ComboBoxOption(tv.name(), tv.toString()));
        }
        return listar;
    }

    @Override
    public List<ComboBoxOption> listarCombobox() {
        List<ComboBoxOption> listar = new ArrayList<>();
        for (Vehiculo v : vehiculoRepository.listarActivos()) {
            listar.add(new ComboBoxOption(String.valueOf(v.getIdVehiculo()), v.getDescripcionCorta()));
        }
        return listar;
    }

    @Override
    public List<Vehiculo> listarActivos() {
        return vehiculoRepository.listarActivos();
    }

    @Override
    public Optional<Vehiculo> buscarPorPlaca(String placa) {
        return vehiculoRepository.findByPlaca(placa);
    }
}
