/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ViajeServiceImp.java                                         │
 * │ CAPA    : Servicio (reglas)                                            │
 * │ MÓDULO  : Flota                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Consulta de salidas y asientos ocupados.                             │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import lombok.RequiredArgsConstructor;
import pe.edu.upeu.syspasajes.enums.Sentido;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Viaje;
import pe.edu.upeu.syspasajes.repository.ICrudGenericoRepository;
import pe.edu.upeu.syspasajes.repository.ViajeRepository;
import pe.edu.upeu.syspasajes.service.IViajeService;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

@RequiredArgsConstructor
public class ViajeServiceImp extends CrudGenericoServiceImp<Viaje, Long> implements IViajeService {

    private final ViajeRepository viajeRepository;

    @Override
    protected ICrudGenericoRepository<Viaje, Long> getRepo() {
        return viajeRepository;
    }

    @Override
    public List<Viaje> listarPorFecha(LocalDate fecha) {
        return viajeRepository.listarPorFecha(fecha);
    }

    @Override
    public List<Viaje> listarDisponibles(LocalDate fecha, Sentido sentido, TipoVehiculo tipo) {
        return viajeRepository.listarDisponibles(fecha, sentido, tipo);
    }

    @Override
    public Set<Integer> asientosOcupados(Long idViaje) {
        return viajeRepository.asientosOcupados(idViaje);
    }

    @Override
    public int contarBoletos(Long idViaje) {
        return viajeRepository.contarBoletos(idViaje);
    }
}
