# ┌────────────────────────────────────────────────────────────────────────┐
# │ ARCHIVO : sincronizar_web.py                                           │
# │ ¿PARA QUÉ SIRVE?                                                       │
# │   La página web/syspasajes.html es el ÚNICO lugar donde se programa    │
# │   la venta de pasajes. Este script la copia a:                         │
# │     · android/app/src/main/assets/www/index.html  (la app Android)     │
# │     · web/sitio/index.html  (sitio web instalable en el celular, PWA)  │
# │   Úselo después de cada cambio:   python herramientas/sincronizar_web.py│
# └────────────────────────────────────────────────────────────────────────┘
import os

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ORIGEN = os.path.join(RAIZ, "web", "syspasajes.html")

html = open(ORIGEN, encoding="utf-8").read()

# 1) App Android: la misma página tal cual
app = os.path.join(RAIZ, "android", "app", "src", "main", "assets", "www", "index.html")
os.makedirs(os.path.dirname(app), exist_ok=True)
open(app, "w", encoding="utf-8").write(html)

# 2) Sitio web: se agrega el manifiesto (para "Agregar a pantalla de inicio") y el trabajador sin conexión
cabecera = ('<link rel="manifest" href="manifest.webmanifest">'
            '<meta name="theme-color" content="#0a2a66">'
            '<link rel="icon" href="icon-192.png"><link rel="apple-touch-icon" href="icon-192.png">')
registro = ('<script>if ("serviceWorker" in navigator && location.protocol === "https:") '
            'navigator.serviceWorker.register("sw.js").catch(() => {});</script>')
sitio_html = html.replace("<title>", cabecera + "<title>", 1).replace("</body></html>", registro + "</body></html>", 1)
sitio = os.path.join(RAIZ, "web", "sitio", "index.html")
os.makedirs(os.path.dirname(sitio), exist_ok=True)
open(sitio, "w", encoding="utf-8").write(sitio_html)

print("Listo:\n  " + app + "\n  " + sitio)
