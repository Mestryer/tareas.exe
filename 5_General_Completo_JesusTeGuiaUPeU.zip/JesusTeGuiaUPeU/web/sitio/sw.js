/* ┌──────────────────────────────────────────────────────────────────────┐
   │ sw.js · trabajador sin conexión del sitio web                        │
   │ Guarda la página y los íconos para que abra aunque no haya internet. │
   │ ► Si cambias index.html sube la versión (v3 → v4) para refrescar.    │
   └──────────────────────────────────────────────────────────────────────┘ */
const CACHE = "jtg-upeu-v3";
const ARCHIVOS = ["./", "./index.html", "./manifest.webmanifest", "./icon-192.png", "./icon-512.png"];
self.addEventListener("install", e => { e.waitUntil(caches.open(CACHE).then(c => c.addAll(ARCHIVOS))); self.skipWaiting(); });
self.addEventListener("activate", e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k))))); self.clients.claim(); });
self.addEventListener("fetch", e => {
  if (e.request.method !== "GET" || !e.request.url.startsWith(self.location.origin)) return;   // Firebase y fuentes van directo a internet
  e.respondWith(fetch(e.request).then(r => { const copia = r.clone(); caches.open(CACHE).then(c => c.put(e.request, copia)); return r; })
    .catch(() => caches.match(e.request)));
});
