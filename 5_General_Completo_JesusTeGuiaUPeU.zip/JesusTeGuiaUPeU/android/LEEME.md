# App Android — Jesús te guía a la UPeU (v3)

App para celular Android (7.0 o superior). Es la **misma página del sitio web** (`web/syspasajes.html`)
dentro de la app, con tres funciones del celular:

| Función | Qué hace | Archivo |
|---|---|---|
| **Aviso al taxista** | Cuando alguien compra un asiento, al taxista de ese vehículo le llega una **notificación del celular** con la reserva (pasajero, asiento, salida, comprobante). | `MainActivity.mostrarNotificacion()` |
| **Imprimir boleta / factura** | Botón *Imprimir*: usa el servicio de impresión de Android (impresora Wi-Fi, Bluetooth o **Guardar como PDF**). Formato ticket o A4. | `MainActivity.imprimirHtml()` |
| **WhatsApp / SMS** | Botón *WhatsApp a Mijael*: abre WhatsApp con el mensaje de reserva ya escrito para el taxista. | `MainActivity.abrirFuera()` |

## Cómo obtener el APK (elige una)

### A) Con GitHub (sin instalar nada)
1. Crea un repositorio en GitHub y sube **toda** la carpeta del proyecto (incluida `.github/`).
2. Ve a **Actions → Construir APK → Run workflow**.
3. En ~5 minutos aparece el archivo **JesusTeGuiaUPeU-apk** para descargar.
4. Pasa `app-debug.apk` al celular y ábrelo (acepta *Instalar apps de origen desconocido*).

### B) Con Android Studio
1. *File → Open* → elige la carpeta `android`.
2. Espera a que termine *Gradle Sync*.
3. *Build → Build App Bundle(s) / APK(s) → Build APK(s)*.
4. El APK queda en `android/app/build/outputs/apk/debug/app-debug.apk`.

## Para que todos los celulares compartan los mismos datos (recomendado)

Sin internet propio, cada celular guarda sus datos por separado. Para que **el aviso llegue al celular del
taxista** cuando el cliente compra desde **otro** celular, conecta una base de datos gratis de Firebase:

1. Entra a https://console.firebase.google.com → *Agregar proyecto* (gratis, plan Spark).
2. *Compilación → Firestore Database → Crear base de datos* (ubicación `southamerica-east1`).
3. En *Reglas* pega esto y publica (proyecto académico; para producción agrega inicio de sesión):
   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /{document=**} { allow read, write: if true; }
     }
   }
   ```
4. *Configuración del proyecto → Tus apps → Web (</>)* → copia `apiKey`, `authDomain` y `projectId`.
5. En `web/syspasajes.html` busca `const CONFIG_FIREBASE = null;` y cámbialo por:
   ```js
   const CONFIG_FIREBASE = { apiKey: "AIza…", authDomain: "tu-proyecto.firebaseapp.com", projectId: "tu-proyecto" };
   ```
6. Ejecuta `python herramientas/sincronizar_web.py` y vuelve a generar el APK.

La primera vez que se abre, la app carga sola los 4 vehículos, las tarifas y el administrador.

> Las notificaciones llegan mientras la app del taxista está abierta o en segundo plano reciente.
> Si el celular cierra la app por ahorro de batería, el taxista verá la reserva en la pestaña **Avisos**
> al volver a abrirla, y el cliente siempre puede reenviarla con el botón **WhatsApp**.

## Cambiar algo
- **Colores, textos, taxistas, precios:** `web/syspasajes.html` (está comentado por secciones) y luego
  `python herramientas/sincronizar_web.py`.
- **Nombre de la app:** `app/src/main/res/values/strings.xml`.
- **Colores de la barra del celular:** `app/src/main/res/values/colors.xml`.
- **Versión:** `app/build.gradle` (`versionCode` y `versionName`).
