# Módulo Marca — SysPasajes UPeU v3 (azul, blanco y dorado)

Marcas de los vehículos (Toyota, Hyundai, Kia, Nissan). Cada vehículo de la flota apunta a una marca. No se elimina una marca con vehículos.

## Archivos (capas Model → Repository → Service → Controller → View)
- `model/Marca.java`
- `repository/MarcaRepository.java`
- `service/IMarcaService.java`
- `service/impl/MarcaServiceImp.java`
- `controller/MarcaController.java`
- `view/main_marca.fxml`
- `tabla.sql` (tabla(s) H2 del módulo)

## Cómo se conecta
Estos archivos son una copia del proyecto general `SysPasajesUPeU`, separados para revisarlos por módulo.
Para que compilen necesitan el resto del proyecto (AppContext, SqlHelper, AbstractJpaRepository, TableViewHelper,
Toast...). En el proyecto general ya están registrados en `config/AppContext.java` y en el menú
(`service/impl/MenuMenuItemDaoImp.java`).
