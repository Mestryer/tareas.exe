/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : MarcaRepository.java                                         │
 * │ CAPA    : Repositorio (base de datos)                                  │
 * │ MÓDULO  : MARCA                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   SQL de la tabla marca: listar activas, buscar por nombre y contar    │
 * │   sus vehículos.                                                       │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import pe.edu.upeu.syspasajes.model.Marca;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

/** MÓDULO MARCA - acceso a la tabla marca. */
public class MarcaRepository extends AbstractJpaRepository<Marca, Long> {

    @Override protected String getTableName() { return "marca"; }
    @Override protected String getPkColumn()  { return "id_marca"; }

    @Override
    public List<Marca> findAll() {
        return executeQuery("SELECT * FROM marca ORDER BY nombre");
    }

    public List<Marca> listarActivas() {
        return executeQuery("SELECT * FROM marca WHERE estado = 'ACTIVO' ORDER BY nombre");
    }

    public Optional<Marca> findByNombre(String nombre) {
        return executeQueryOne("SELECT * FROM marca WHERE UPPER(nombre) = UPPER(?)", nombre);
    }

    /** Cuántos vehículos usan la marca (no se puede eliminar si tiene vehículos). */
    public int contarVehiculos(Long idMarca) {
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM vehiculo WHERE id_marca = ?")) {
            ps.setLong(1, idMarca);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error contando vehículos de la marca", e);
        }
    }

    @Override
    protected Marca mapRow(ResultSet rs) throws SQLException {
        return Marca.builder()
                .idMarca(rs.getLong("id_marca"))
                .nombre(rs.getString("nombre"))
                .paisOrigen(rs.getString("pais_origen"))
                .estado(rs.getString("estado"))
                .build();
    }

    @Override
    protected Marca insert(Connection conn, Marca e) throws SQLException {
        long id = executeInsertGetKey(conn,
                "INSERT INTO marca(nombre,pais_origen,estado) VALUES(?,?,?)",
                e.getNombre(), e.getPaisOrigen(), e.getEstado());
        e.setIdMarca(id);
        return e;
    }

    @Override
    protected Marca updateRow(Connection conn, Marca e) throws SQLException {
        executeUpdate(conn,
                "UPDATE marca SET nombre=?,pais_origen=?,estado=? WHERE id_marca=?",
                e.getNombre(), e.getPaisOrigen(), e.getEstado(), e.getIdMarca());
        return e;
    }
}
