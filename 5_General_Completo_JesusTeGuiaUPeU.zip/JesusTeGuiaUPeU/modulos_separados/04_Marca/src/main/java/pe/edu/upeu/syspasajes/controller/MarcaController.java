/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : MarcaController.java                                         │
 * │ CAPA    : Controlador (pantalla)                                       │
 * │ MÓDULO  : MARCA                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Pantalla Marcas: registrar, modificar y eliminar marcas de           │
 * │   vehículos.                                                           │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import pe.edu.upeu.syspasajes.components.ColumnInfo;
import pe.edu.upeu.syspasajes.components.TableViewHelper;
import pe.edu.upeu.syspasajes.components.Toast;
import pe.edu.upeu.syspasajes.components.ToltipCustom;
import pe.edu.upeu.syspasajes.model.Marca;
import pe.edu.upeu.syspasajes.service.IMarcaService;

import java.util.*;
import java.util.function.Consumer;

/** MÓDULO MARCA - CRUD de marcas de vehículos. */
public class MarcaController {

    private final IMarcaService ms;

    @FXML TextField txtNombre, txtPais, txtFiltroDato;
    @FXML ComboBox<String> cbxEstado;
    @FXML Label lbnMsg;
    @FXML Button btnGuardar;
    @FXML private TableView<Marca> tableView;
    @FXML private AnchorPane miContenedor;

    private Validator validator;
    private final ToltipCustom ttc = new ToltipCustom();
    private List<Marca> lista = new ArrayList<>();
    private Long idMarcaCE = 0L;

    public MarcaController(IMarcaService ms) {
        this.ms = ms;
    }

    @FXML
    public void initialize() {
        idMarcaCE = 0L;
        validator = Validation.buildDefaultValidatorFactory().getValidator();
        cbxEstado.getItems().setAll("ACTIVO", "INACTIVO");
        cbxEstado.getSelectionModel().select("ACTIVO");
        txtFiltroDato.textProperty().addListener((o, a, n) -> filtrar());

        TableViewHelper<Marca> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("ID", new ColumnInfo("idMarca", 60.0));
        columns.put("Marca", new ColumnInfo("nombre", 180.0));
        columns.put("País de origen", new ColumnInfo("paisOrigen", 160.0));
        columns.put("Estado", new ColumnInfo("estado", 90.0));
        Consumer<Marca> updateAction = this::editForm;
        Consumer<Marca> deleteAction = m -> {
            if (!confirmar("¿Eliminar la marca " + m.getNombre() + "?")) return;
            try {
                ms.delete(m.getIdMarca());
                Toast.mostrar(stage(), "Marca eliminada correctamente", Toast.EXITO);
                if (Objects.equals(idMarcaCE, m.getIdMarca())) clearForm();
            } catch (Exception ex) {
                Toast.mostrar(stage(), "No se puede eliminar: " + ex.getMessage(), Toast.ERROR);
            }
            listar();
        };
        helper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        tableView.setPlaceholder(new Label("No hay marcas registradas"));
        lbnMsg.setText("");
        listar();
    }

    public void listar() {
        lista = ms.findAll();
        filtrar();
    }

    private void filtrar() {
        String f = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        tableView.setItems(FXCollections.observableArrayList(lista.stream()
                .filter(m -> f.isEmpty() || m.getNombre().toLowerCase().contains(f)
                        || (m.getPaisOrigen() != null && m.getPaisOrigen().toLowerCase().contains(f)))
                .toList()));
    }

    @FXML
    public void validarFormulario() {
        limpiarError();
        String pais = txt(txtPais);
        Marca formulario = Marca.builder()
                .nombre(txt(txtNombre))
                .paisOrigen(pais.isEmpty() ? null : pais)
                .estado(cbxEstado.getSelectionModel().getSelectedItem())
                .build();
        List<ConstraintViolation<Marca>> errores = new ArrayList<>(validator.validate(formulario));
        if (!errores.isEmpty()) {
            ConstraintViolation<Marca> e = errores.get(0);
            Control c = switch (e.getPropertyPath().toString()) {
                case "paisOrigen" -> txtPais;
                case "estado" -> cbxEstado;
                default -> txtNombre;
            };
            error(c, e.getMessage());
            return;
        }
        Optional<Marca> mismoNombre = ms.buscarPorNombre(formulario.getNombre());
        if (mismoNombre.isPresent() && !mismoNombre.get().getIdMarca().equals(idMarcaCE)) {
            error(txtNombre, "Ya existe la marca " + formulario.getNombre());
            return;
        }
        try {
            if (idMarcaCE > 0L) {
                formulario.setIdMarca(idMarcaCE);
                ms.update(idMarcaCE, formulario);
                Toast.mostrar(stage(), "Marca actualizada correctamente", Toast.EXITO);
            } else {
                ms.save(formulario);
                Toast.mostrar(stage(), "Marca registrada correctamente", Toast.EXITO);
            }
            clearForm();
            lbnMsg.setText("Formulario guardado");
            lbnMsg.setStyle("-fx-text-fill: #1553c7; -fx-font-size: 14px;");
            listar();
        } catch (Exception ex) {
            lbnMsg.setText("Error al guardar: " + ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 14px;");
        }
    }

    public void editForm(Marca m) {
        limpiarError();
        idMarcaCE = m.getIdMarca();
        txtNombre.setText(m.getNombre());
        txtPais.setText(m.getPaisOrigen() == null ? "" : m.getPaisOrigen());
        cbxEstado.getSelectionModel().select(m.getEstado());
        btnGuardar.setText("Actualizar");
        lbnMsg.setText("Editando marca " + m.getNombre());
        lbnMsg.setStyle("-fx-text-fill: #1565c0; -fx-font-size: 14px;");
    }

    @FXML
    public void clearForm() {
        txtNombre.clear();
        txtPais.clear();
        cbxEstado.getSelectionModel().select("ACTIVO");
        idMarcaCE = 0L;
        btnGuardar.setText("Guardar");
        lbnMsg.setText("");
        limpiarError();
    }

    private void error(Control c, String msg) {
        ttc.marcarError(c, msg);
        lbnMsg.setText(msg);
        lbnMsg.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 14px;");
        Platform.runLater(c::requestFocus);
    }

    private void limpiarError() {
        List.of(txtNombre, txtPais, cbxEstado).forEach(ttc::limpiarCampo);
    }

    private String txt(TextField tf) {
        return tf.getText() == null ? "" : tf.getText().trim();
    }

    private boolean confirmar(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, mensaje, ButtonType.OK, ButtonType.CANCEL);
        alert.setTitle("Confirmación");
        alert.setHeaderText(null);
        return alert.showAndWait().filter(b -> b == ButtonType.OK).isPresent();
    }

    private Stage stage() {
        return (Stage) miContenedor.getScene().getWindow();
    }
}
