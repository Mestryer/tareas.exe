/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : MarcaServiceImp.java                                         │
 * │ CAPA    : Servicio (reglas)                                            │
 * │ MÓDULO  : MARCA                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Reglas de marcas: no se elimina una marca que tiene vehículos.       │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import pe.edu.upeu.syspasajes.model.Marca;
import pe.edu.upeu.syspasajes.repository.ICrudGenericoRepository;
import pe.edu.upeu.syspasajes.repository.MarcaRepository;
import pe.edu.upeu.syspasajes.service.IMarcaService;

import java.util.List;
import java.util.Optional;

public class MarcaServiceImp extends CrudGenericoServiceImp<Marca, Long> implements IMarcaService {

    private final MarcaRepository marcaRepository;

    public MarcaServiceImp(MarcaRepository marcaRepository) {
        this.marcaRepository = marcaRepository;
    }

    @Override
    protected ICrudGenericoRepository<Marca, Long> getRepo() {
        return marcaRepository;
    }

    @Override
    public List<Marca> listarActivas() {
        return marcaRepository.listarActivas();
    }

    @Override
    public Optional<Marca> buscarPorNombre(String nombre) {
        return marcaRepository.findByNombre(nombre);
    }

    @Override
    public int contarVehiculos(Long idMarca) {
        return marcaRepository.contarVehiculos(idMarca);
    }

    /** No se elimina una marca que tiene vehículos (se debe poner INACTIVO). */
    @Override
    public void delete(Long id) {
        if (marcaRepository.contarVehiculos(id) > 0) {
            throw new IllegalStateException("La marca tiene vehículos registrados. Márquela como INACTIVO.");
        }
        super.delete(id);
    }
}
