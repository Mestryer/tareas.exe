/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : IMarcaService.java                                           │
 * │ CAPA    : Servicio (interfaz)                                          │
 * │ MÓDULO  : MARCA                                                        │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Qué se puede hacer con marcas: CRUD, activas y búsqueda por          │
 * │   nombre.                                                              │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service;

import pe.edu.upeu.syspasajes.model.Marca;

import java.util.List;
import java.util.Optional;

/** MÓDULO MARCA - reglas de negocio. */
public interface IMarcaService extends ICrudGenericoService<Marca, Long> {
    List<Marca> listarActivas();
    Optional<Marca> buscarPorNombre(String nombre);
    int contarVehiculos(Long idMarca);
}
