# Módulo Cliente — SysPasajes UPeU v3 (azul, blanco y dorado)

Clientes que compran pasajes. Se identifican con su DNI (clave primaria). CRUD completo, consulta RENIEC y bloqueo para no eliminar clientes con ventas.

## Archivos (capas Model → Repository → Service → Controller → View)
- `model/Cliente.java`
- `enums/TipoDocumento.java`
- `repository/ClienteRepository.java`
- `service/IClienteService.java`
- `service/impl/ClienteServiceImp.java`
- `controller/ClienteController.java`
- `view/main_cliente.fxml`
- `tabla.sql` (tabla(s) H2 del módulo)

## Cómo se conecta
Estos archivos son una copia del proyecto general `SysPasajesUPeU`, separados para revisarlos por módulo.
Para que compilen necesitan el resto del proyecto (AppContext, SqlHelper, AbstractJpaRepository, TableViewHelper,
Toast...). En el proyecto general ya están registrados en `config/AppContext.java` y en el menú
(`service/impl/MenuMenuItemDaoImp.java`).
