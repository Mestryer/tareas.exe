/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ClienteRepository.java                                       │
 * │ CAPA    : Repositorio (base de datos)                                  │
 * │ MÓDULO  : CLIENTE                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   SQL de la tabla cliente: insertar, actualizar, buscar por DNI y      │
 * │   contar sus ventas.                                                   │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.repository;

import pe.edu.upeu.syspasajes.enums.TipoDocumento;
import pe.edu.upeu.syspasajes.model.Cliente;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/** MÓDULO CLIENTE - acceso a la tabla cliente (PK = DNI). */
public class ClienteRepository extends AbstractJpaRepository<Cliente, String> {

    @Override protected String getTableName() { return "cliente"; }
    @Override protected String getPkColumn()  { return "dni"; }

    @Override
    public List<Cliente> findAll() {
        return executeQuery("SELECT * FROM cliente ORDER BY nombres");
    }

    /** Arma un Cliente a partir de las columnas dni, nombres, telefono, email, direccion, tipo_documento. */
    public static Cliente mapCliente(ResultSet rs) throws SQLException {
        return Cliente.builder()
                .dni(rs.getString("dni"))
                .nombres(rs.getString("nombres"))
                .telefono(rs.getString("telefono"))
                .email(rs.getString("email"))
                .direccion(rs.getString("direccion"))
                .tipoDocumento(TipoDocumento.valueOf(rs.getString("tipo_documento")))
                .build();
    }

    @Override
    protected Cliente mapRow(ResultSet rs) throws SQLException {
        return mapCliente(rs);
    }

    /** Cuántas ventas tiene el cliente (no se puede eliminar si ya compró). */
    public int contarVentas(String dni) {
        try (Connection conn = openConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT COUNT(*) FROM venta_pasaje WHERE dni = ?")) {
            ps.setString(1, dni);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error contando ventas del cliente", e);
        }
    }

    @Override
    protected Cliente insert(Connection conn, Cliente e) throws SQLException {
        // La PK es el DNI (no autogenerada): se usa executeUpdate y no executeInsertGetKey
        executeUpdate(conn,
                "INSERT INTO cliente(dni,nombres,telefono,email,direccion,tipo_documento) VALUES(?,?,?,?,?,?)",
                e.getDni(), e.getNombres(), e.getTelefono(), e.getEmail(), e.getDireccion(), e.getTipoDocumento().name());
        return e;
    }

    @Override
    protected Cliente updateRow(Connection conn, Cliente e) throws SQLException {
        executeUpdate(conn,
                "UPDATE cliente SET nombres=?,telefono=?,email=?,direccion=?,tipo_documento=? WHERE dni=?",
                e.getNombres(), e.getTelefono(), e.getEmail(), e.getDireccion(), e.getTipoDocumento().name(), e.getDni());
        return e;
    }
}
