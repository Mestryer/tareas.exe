/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Cliente.java                                                 │
 * │ CAPA    : Modelo (datos)                                               │
 * │ MÓDULO  : CLIENTE                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Datos del cliente: DNI, nombres, celular, correo, dirección y tipo   │
 * │   de documento, con sus validaciones.                                  │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.syspasajes.enums.TipoDocumento;

/** MÓDULO CLIENTE: persona que compra el pasaje. Se identifica con su DNI. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Cliente {

    @NotBlank(message = "El DNI es obligatorio")
    @Pattern(regexp = "^[0-9A-Za-z]{8,12}$", message = "El documento debe tener entre 8 y 12 caracteres (DNI = 8 dígitos)")
    private String dni;

    @NotBlank(message = "Los nombres son obligatorios")
    @Size(max = 80, message = "Los nombres admiten máximo 80 caracteres")
    private String nombres;

    @Pattern(regexp = "^9\\d{8}$", message = "El celular debe tener 9 dígitos y empezar con 9")
    private String telefono;

    @Email(message = "El correo no tiene un formato válido")
    @Size(max = 80, message = "El correo admite máximo 80 caracteres")
    private String email;

    @Size(max = 120, message = "La dirección admite máximo 120 caracteres")
    private String direccion;

    @NotNull(message = "El tipo de documento es obligatorio")
    private TipoDocumento tipoDocumento;

    public String getTipoDocumentoTexto() {
        return tipoDocumento == null ? "" : tipoDocumento.name();
    }

    @Override
    public String toString() {
        return dni + " - " + nombres;
    }
}
