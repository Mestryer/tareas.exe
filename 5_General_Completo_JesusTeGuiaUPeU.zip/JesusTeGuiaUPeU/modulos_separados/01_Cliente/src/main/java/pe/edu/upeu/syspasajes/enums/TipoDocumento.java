/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : TipoDocumento.java                                           │
 * │ CAPA    : Enumeración                                                  │
 * │ MÓDULO  : CLIENTE                                                      │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Tipos de documento del cliente: DNI, carné de extranjería o          │
 * │   pasaporte.                                                           │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.enums;

public enum TipoDocumento {
    DNI,
    CE,
    PASAPORTE
}
