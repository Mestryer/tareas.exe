-- CLIENTE: persona que compra el pasaje (se identifica con su DNI)
CREATE TABLE IF NOT EXISTS cliente (
    dni            VARCHAR(12) PRIMARY KEY,
    nombres        VARCHAR(80) NOT NULL,
    telefono       VARCHAR(15),
    email          VARCHAR(80),
    direccion      VARCHAR(120),
    tipo_documento VARCHAR(12) NOT NULL
);
