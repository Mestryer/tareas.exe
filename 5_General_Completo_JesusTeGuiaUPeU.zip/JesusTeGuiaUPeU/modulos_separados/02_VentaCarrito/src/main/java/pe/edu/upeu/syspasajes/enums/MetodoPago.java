/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : MetodoPago.java                                              │
 * │ CAPA    : Enumeración                                                  │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Formas de pago: Efectivo (con vuelto), Yape, Plin, Tarjeta y         │
 * │   Transferencia (con N° de operación).                                 │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.enums;

import lombok.Getter;

/** Formas de pago aceptadas al vender el pasaje. */
@Getter
public enum MetodoPago {
    EFECTIVO("Efectivo", false),
    YAPE("Yape", true),
    PLIN("Plin", true),
    TARJETA("Tarjeta débito / crédito", true),
    TRANSFERENCIA("Transferencia bancaria", true);

    private final String descripcion;
    /** true = se pide el N° de operación / voucher; false = se pide el monto recibido (vuelto). */
    private final boolean requiereOperacion;

    MetodoPago(String descripcion, boolean requiereOperacion) {
        this.descripcion = descripcion;
        this.requiereOperacion = requiereOperacion;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
