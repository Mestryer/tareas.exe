/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VentaPasaje.java                                             │
 * │ CAPA    : Modelo (datos)                                               │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Cabecera de la boleta o factura: cliente, RUC, forma de pago,        │
 * │   vuelto y totales.                                                    │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.experimental.SuperBuilder;
import pe.edu.upeu.syspasajes.enums.MetodoPago;

import java.time.LocalDateTime;
import java.util.List;

/** Venta de pasajes (cabecera de la boleta o factura). Hereda de DocumentoComercial. */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class VentaPasaje extends DocumentoComercial {
    private Cliente cliente;
    private Usuario idUsuario;
    private LocalDateTime fechaVenta;
    private double descuento;
    /** Solo para FACTURA. */
    private String ruc;
    private String razonSocial;
    /** Forma de pago. */
    private MetodoPago metodoPago;
    private String nroOperacion;
    private double montoRecibido;
    private double vuelto;
    private List<Boleto> boletos;

    public boolean esFactura() {
        return "FACTURA".equals(getTipoDoc());
    }

    public String getComprobanteTexto() {
        return getSerie() + "-" + getNumDoc();
    }

    /** Total = base imponible + IGV (el descuento ya se aplicó antes de calcular la base). */
    @Override
    public double calcularTotal() {
        return Math.round((getPrecioBase() + getIgv()) * 100.0) / 100.0;
    }
}
