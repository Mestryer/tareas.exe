/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : TipoComprobante.java                                         │
 * │ CAPA    : Enumeración                                                  │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Boleta (serie B001, con DNI) o Factura (serie F001, con RUC).        │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.enums;

import lombok.Getter;

/** Comprobante que se emite: boleta (con DNI) o factura (con RUC). */
@Getter
public enum TipoComprobante {
    BOLETA("Boleta de venta", "B001"),
    FACTURA("Factura", "F001");

    private final String descripcion;
    private final String serie;

    TipoComprobante(String descripcion, String serie) {
        this.descripcion = descripcion;
        this.serie = serie;
    }

    @Override
    public String toString() {
        return descripcion;
    }
}
