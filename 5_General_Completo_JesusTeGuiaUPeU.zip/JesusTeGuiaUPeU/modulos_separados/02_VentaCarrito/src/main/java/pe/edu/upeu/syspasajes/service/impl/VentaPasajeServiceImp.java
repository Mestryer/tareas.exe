/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VentaPasajeServiceImp.java                                   │
 * │ CAPA    : Servicio (reglas)                                            │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Calcula IGV y total, valida RUC (dígito verificador), forma de       │
 * │   pago y vuelto, y arma la boleta o factura.                           │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import pe.edu.upeu.syspasajes.dto.DatosPago;
import pe.edu.upeu.syspasajes.dto.VentaResumen;
import pe.edu.upeu.syspasajes.enums.MetodoPago;
import pe.edu.upeu.syspasajes.enums.TipoComprobante;
import pe.edu.upeu.syspasajes.exception.ModelNotFoundException;
import pe.edu.upeu.syspasajes.model.Boleto;
import pe.edu.upeu.syspasajes.model.VentaCarrito;
import pe.edu.upeu.syspasajes.model.Cliente;
import pe.edu.upeu.syspasajes.model.Usuario;
import pe.edu.upeu.syspasajes.model.VentaPasaje;
import pe.edu.upeu.syspasajes.repository.BoletoRepository;
import pe.edu.upeu.syspasajes.repository.ICrudGenericoRepository;
import pe.edu.upeu.syspasajes.repository.VentaCarritoRepository;
import pe.edu.upeu.syspasajes.repository.ClienteRepository;
import pe.edu.upeu.syspasajes.repository.UsuarioRepository;
import pe.edu.upeu.syspasajes.repository.VentaPasajeRepository;
import pe.edu.upeu.syspasajes.service.IVentaPasajeService;
import pe.edu.upeu.syspasajes.utils.AvisoTaxista;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

public class VentaPasajeServiceImp extends CrudGenericoServiceImp<VentaPasaje, Long>
        implements IVentaPasajeService {

    private static final Logger logger = LoggerFactory.getLogger(VentaPasajeServiceImp.class);

    private final VentaPasajeRepository ventaRepository;
    private final BoletoRepository boletoRepository;
    private final VentaCarritoRepository carritoRepository;
    private final ClienteRepository clienteRepository;
    private final UsuarioRepository usuarioRepository;

    public VentaPasajeServiceImp(VentaPasajeRepository ventaRepository, BoletoRepository boletoRepository,
                                 VentaCarritoRepository carritoRepository, ClienteRepository clienteRepository,
                                 UsuarioRepository usuarioRepository) {
        this.ventaRepository = ventaRepository;
        this.boletoRepository = boletoRepository;
        this.carritoRepository = carritoRepository;
        this.clienteRepository = clienteRepository;
        this.usuarioRepository = usuarioRepository;
    }

    @Override
    protected ICrudGenericoRepository<VentaPasaje, Long> getRepo() {
        return ventaRepository;
    }

    @Override
    public VentaPasaje registrarVenta(String dni, Long idUsuario, double descuento, DatosPago pago) {
        Cliente cliente = clienteRepository.findById(dni)
                .orElseThrow(() -> new ModelNotFoundException("El cliente con DNI " + dni + " no está registrado"));
        Usuario usuario = usuarioRepository.findById(idUsuario)
                .orElseThrow(() -> new ModelNotFoundException("Usuario de sesión no válido"));

        List<VentaCarrito> items = carritoRepository.listaCarritoCliente(dni);
        if (items.isEmpty()) {
            throw new IllegalStateException("No hay asientos en el carrito (las reservas duran 15 minutos)");
        }
        for (VentaCarrito item : items) {
            if (item.getViaje().yaPartio()) {
                throw new IllegalStateException("La salida de las " + item.getViaje().getHoraTexto()
                        + " ya partió. Quite el asiento " + item.getNroAsiento() + " del carrito.");
            }
        }

        double subtotal = redondear(items.stream().mapToDouble(VentaCarrito::getPrecio).sum());
        if (descuento < 0 || descuento > subtotal) {
            throw new IllegalArgumentException("El descuento debe estar entre 0 y " + subtotal);
        }
        double total = redondear(subtotal - descuento);
        double base = redondear(total / (1 + TASA_IGV));
        double igv = redondear(total - base);

        // ---- Comprobante y forma de pago ----
        if (pago == null) pago = DatosPago.builder().tipoComprobante(TipoComprobante.BOLETA)
                .metodoPago(MetodoPago.EFECTIVO).montoRecibido(total).build();
        TipoComprobante tipo = pago.getTipoComprobante() == null ? TipoComprobante.BOLETA : pago.getTipoComprobante();
        String ruc = null, razon = null;
        if (tipo == TipoComprobante.FACTURA) {
            ruc = pago.getRuc() == null ? "" : pago.getRuc().trim();
            razon = pago.getRazonSocial() == null ? "" : pago.getRazonSocial().trim().toUpperCase();
            validarRuc(ruc);
            if (razon.isEmpty()) throw new IllegalArgumentException("Para factura escriba la razón social");
            if (razon.length() > 100) razon = razon.substring(0, 100);
        }
        MetodoPago metodo = pago.getMetodoPago() == null ? MetodoPago.EFECTIVO : pago.getMetodoPago();
        String operacion = null;
        double recibido, vuelto;
        if (metodo.isRequiereOperacion()) {
            operacion = pago.getNroOperacion() == null ? "" : pago.getNroOperacion().trim();
            if (!operacion.matches("[A-Za-z0-9-]{4,30}")) {
                throw new IllegalArgumentException("Escriba el N° de operación / voucher de " + metodo.getDescripcion()
                        + " (4 a 30 letras o números)");
            }
            recibido = total;
            vuelto = 0;
        } else {
            recibido = redondear(pago.getMontoRecibido());
            if (recibido < total) {
                throw new IllegalArgumentException(String.format("El monto recibido (S/ %.2f) es menor que el total (S/ %.2f)",
                        recibido, total));
            }
            vuelto = redondear(recibido - total);
        }

        VentaPasaje venta = VentaPasaje.builder()
                .cliente(cliente)
                .idUsuario(usuario)
                .precioBase(base)
                .igv(igv)
                .descuento(redondear(descuento))
                .precioTotal(total)
                .serie(tipo.getSerie())
                .numDoc("PENDIENTE")
                .tipoDoc(tipo.name())
                .ruc(ruc)
                .razonSocial(razon)
                .metodoPago(metodo)
                .nroOperacion(operacion)
                .montoRecibido(recibido)
                .vuelto(vuelto)
                .fechaVenta(LocalDateTime.now().withNano(0))
                .build();

        VentaPasaje registrada = ventaRepository.registrarVentaCompleta(venta, items);
        logger.info("Venta registrada {}-{} por S/ {} ({})", registrada.getSerie(), registrada.getNumDoc(), total, metodo);
        // ► AVISO DE RESERVA: deja el mensaje para el taxista de cada vehículo (tabla NOTIFICACION)
        AvisoTaxista.registrar(registrada);
        return registrada;
    }

    /** RUC peruano: 11 dígitos, empieza en 10 (persona natural) o 20 (empresa) y cuadra su dígito verificador. */
    private void validarRuc(String ruc) {
        if (!rucValido(ruc)) {
            throw new IllegalArgumentException("El RUC no es válido: 11 dígitos, empieza con 10 o 20 y su último dígito debe cuadrar");
        }
    }

    /** Dígito verificador del RUC (módulo 11 de SUNAT) sobre los 10 primeros dígitos. */
    private static int digitoVerificador(String diez) {
        int[] peso = {5, 4, 3, 2, 7, 6, 5, 4, 3, 2};
        int suma = 0;
        for (int i = 0; i < 10; i++) suma += peso[i] * (diez.charAt(i) - '0');
        int r = 11 - (suma % 11);
        return r == 10 ? 0 : (r == 11 ? 1 : r);
    }

    @Override
    public boolean rucValido(String ruc) {
        return ruc != null && ruc.matches("(10|15|17|20)\\d{9}")
                && digitoVerificador(ruc.substring(0, 10)) == ruc.charAt(10) - '0';
    }

    @Override
    public String rucDeDni(String dni) {
        if (dni == null || !dni.matches("\\d{8}")) return "";
        String diez = "10" + dni;
        return diez + digitoVerificador(diez);
    }

    @Override
    public java.util.Optional<String> buscarRazonSocial(String ruc) {
        if (!rucValido(ruc)) return java.util.Optional.empty();
        if (ruc.startsWith("10")) {
            java.util.Optional<String> nombre = clienteRepository.findById(ruc.substring(2, 10)).map(Cliente::getNombres);
            if (nombre.isPresent()) return nombre;
        }
        return ventaRepository.ultimaRazonSocial(ruc);
    }

    @Override
    public List<VentaResumen> listarResumen(LocalDate desde, LocalDate hasta) {
        return ventaRepository.listarResumen(desde, hasta);
    }

    @Override
    public List<Boleto> listarBoletos(Long idVenta) {
        return boletoRepository.listarPorVenta(idVenta);
    }

    @Override
    public String generarTextoBoleta(VentaPasaje v) {
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        boolean factura = v.esFactura();
        StringBuilder sb = new StringBuilder();
        sb.append("            JESÚS TE GUÍA A LA UPeU\n");
        sb.append("   Universidad UPeU <-> C.C. Plaza de Armas\n");
        sb.append("              RUC 20123456786\n");
        sb.append("------------------------------------------------\n");
        sb.append(String.format("%-20s %s-%s%n", factura ? "FACTURA ELECTRÓNICA" : "BOLETA DE VENTA", v.getSerie(), v.getNumDoc()));
        sb.append(String.format("Fecha   : %s%n", v.getFechaVenta() == null ? "" : v.getFechaVenta().format(f)));
        if (factura) {
            sb.append(String.format("RUC     : %s%n", v.getRuc()));
            sb.append(String.format("Razón s.: %s%n", v.getRazonSocial()));
            sb.append(String.format("Pasajero: %s (DNI %s)%n", v.getCliente().getNombres(), v.getCliente().getDni()));
        } else {
            sb.append(String.format("DNI     : %s%n", v.getCliente().getDni()));
            sb.append(String.format("Cliente : %s%n", v.getCliente().getNombres()));
        }
        if (v.getCliente().getDireccion() != null && !v.getCliente().getDireccion().isBlank()) {
            sb.append(String.format("Direcc. : %s%n", v.getCliente().getDireccion()));
        }
        sb.append("------------------------------------------------\n");
        sb.append(String.format("%-4s %-22s %-11s %7s%n", "Ast.", "Ruta / Salida", "Vehículo", "Precio"));
        if (v.getBoletos() != null) {
            for (Boleto b : v.getBoletos()) {
                sb.append(String.format("%-4s %-22s %-11s %7.2f%n",
                        b.getNroAsiento(),
                        recortar(b.getViaje().getSentido().getOrigen(), 22),
                        recortar(b.getViaje().getTipoTexto(), 11),
                        b.getPrecio()));
                sb.append(String.format("     -> %-19s %s%n",
                        recortar(b.getViaje().getSentido().getDestino(), 19),
                        b.getViaje().getPlaca()));
                sb.append(String.format("     Salida: %s %s  Conductor: %s%n", b.getViaje().getFechaTexto(),
                        b.getViaje().getHoraTexto(), recortar(b.getViaje().getConductor(), 18)));
            }
        }
        sb.append("------------------------------------------------\n");
        sb.append(String.format("%-32s S/ %9.2f%n", "Descuento:", v.getDescuento()));
        sb.append(String.format("%-32s S/ %9.2f%n", "Op. gravada:", v.getPrecioBase()));
        sb.append(String.format("%-32s S/ %9.2f%n", "IGV (18%):", v.getIgv()));
        sb.append(String.format("%-32s S/ %9.2f%n", "TOTAL A PAGAR:", v.getPrecioTotal()));
        sb.append("------------------------------------------------\n");
        String metodo = v.getMetodoPago() == null ? "Efectivo" : v.getMetodoPago().getDescripcion();
        sb.append(String.format("Forma de pago: %s%n", metodo));
        if (v.getMetodoPago() != null && v.getMetodoPago().isRequiereOperacion()) {
            sb.append(String.format("N° operación : %s%n", v.getNroOperacion()));
        } else {
            sb.append(String.format("%-32s S/ %9.2f%n", "Recibido:", v.getMontoRecibido()));
            sb.append(String.format("%-32s S/ %9.2f%n", "Vuelto:", v.getVuelto()));
        }
        sb.append("------------------------------------------------\n");
        sb.append("   «Yo soy el camino» (Juan 14:6) ¡Buen viaje!\n");
        return sb.toString();
    }

    private static double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }

    private static String recortar(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max);
    }
}
