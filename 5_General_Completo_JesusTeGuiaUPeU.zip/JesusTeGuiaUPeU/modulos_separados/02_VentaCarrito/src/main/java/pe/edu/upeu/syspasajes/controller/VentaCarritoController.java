/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VentaCarritoController.java                                  │
 * │ CAPA    : Controlador (pantalla)                                       │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Pantalla Venta carrito: muestra los asientos reservados sin pagar    │
 * │   y permite liberarlos o vaciar el carrito de un DNI.                  │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import pe.edu.upeu.syspasajes.components.ColumnInfo;
import pe.edu.upeu.syspasajes.components.TableViewHelper;
import pe.edu.upeu.syspasajes.components.Toast;
import pe.edu.upeu.syspasajes.model.VentaCarrito;
import pe.edu.upeu.syspasajes.service.IVentaCarritoService;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.function.Consumer;

/**
 * MÓDULO VENTA CARRITO - muestra los asientos reservados en los carritos (aún sin pagar).
 * Permite liberar una reserva, vaciar el carrito de un cliente y liberar las vencidas.
 */
public class VentaCarritoController {

    private final IVentaCarritoService cs;

    @FXML TextField txtFiltroDni;
    @FXML Label lblResumen;
    @FXML private TableView<VentaCarrito> tableView;
    @FXML private AnchorPane miContenedor;

    private List<VentaCarrito> lista = List.of();

    public VentaCarritoController(IVentaCarritoService cs) {
        this.cs = cs;
    }

    @FXML
    public void initialize() {
        TableViewHelper<VentaCarrito> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("ID", new ColumnInfo("idCarrito", 50.0));
        columns.put("DNI", new ColumnInfo("dni", 85.0));
        columns.put("Cliente", new ColumnInfo("nombreCliente", 200.0));
        columns.put("Asiento", new ColumnInfo("nroAsiento", 65.0));
        columns.put("Ruta", new ColumnInfo("rutaTexto", 250.0));
        columns.put("Salida", new ColumnInfo("salidaTexto", 120.0));
        columns.put("Vehículo", new ColumnInfo("vehiculoTexto", 110.0));
        columns.put("Precio", new ColumnInfo("precioTexto", 75.0));
        columns.put("Reservado", new ColumnInfo("reservadoTexto", 95.0));
        columns.put("Min. restantes", new ColumnInfo("minutosRestantes", 100.0));
        Consumer<VentaCarrito> updateAction = c -> Toast.mostrar(stage(),
                "Para cambiar el asiento use «Vender pasaje»: quite el asiento y elija otro en el croquis.", Toast.INFO);
        Consumer<VentaCarrito> deleteAction = c -> {
            if (!confirmar("¿Liberar el asiento " + c.getNroAsiento() + " reservado por " + c.getDni() + "?")) return;
            try {
                cs.delete(c.getIdCarrito());
                Toast.mostrar(stage(), "Asiento liberado", Toast.EXITO);
            } catch (Exception ex) {
                Toast.mostrar(stage(), "La reserva ya no existe (venció o se vendió)", Toast.AVISO);
            }
            listar();
        };
        helper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        tableView.setPlaceholder(new Label("No hay asientos reservados en ningún carrito"));
        txtFiltroDni.textProperty().addListener((o, a, n) -> filtrar());
        listar();
    }

    @FXML
    public void listar() {
        cs.liberarReservasVencidas();
        lista = cs.findAll();
        filtrar();
    }

    private void filtrar() {
        String f = txtFiltroDni.getText() == null ? "" : txtFiltroDni.getText().trim().toLowerCase();
        List<VentaCarrito> filtrados = lista.stream()
                .filter(c -> f.isEmpty() || c.getDni().contains(f)
                        || (c.getNombreCliente() != null && c.getNombreCliente().toLowerCase().contains(f)))
                .toList();
        tableView.setItems(FXCollections.observableArrayList(filtrados));
        double total = filtrados.stream().mapToDouble(VentaCarrito::getPrecio).sum();
        lblResumen.setText(filtrados.size() + " asiento(s) reservado(s) · S/ " + String.format("%.2f", total)
                + " · las reservas duran " + IVentaCarritoService.MINUTOS_RESERVA + " minutos");
    }

    @FXML
    public void vaciarCarritoDni() {
        String dni = txtFiltroDni.getText() == null ? "" : txtFiltroDni.getText().trim();
        if (!dni.matches("[0-9A-Za-z]{8,12}")) {
            Toast.mostrar(stage(), "Escriba el DNI del cliente en el filtro", Toast.AVISO);
            return;
        }
        if (!confirmar("¿Vaciar todo el carrito del DNI " + dni + "?")) return;
        cs.deleteCarAll(dni);
        Toast.mostrar(stage(), "Carrito del DNI " + dni + " vaciado", Toast.EXITO);
        listar();
    }

    @FXML
    public void liberarVencidas() {
        int n = cs.liberarReservasVencidas();
        Toast.mostrar(stage(), n + " reserva(s) vencida(s) liberada(s)", Toast.INFO);
        listar();
    }

    private boolean confirmar(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, mensaje, ButtonType.OK, ButtonType.CANCEL);
        alert.setTitle("Confirmación");
        alert.setHeaderText(null);
        return alert.showAndWait().filter(b -> b == ButtonType.OK).isPresent();
    }

    private Stage stage() {
        return (Stage) miContenedor.getScene().getWindow();
    }
}
