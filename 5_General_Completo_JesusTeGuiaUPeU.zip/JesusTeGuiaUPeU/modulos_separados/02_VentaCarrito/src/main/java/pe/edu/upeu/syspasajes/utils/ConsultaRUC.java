/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ConsultaRUC.java                                             │
 * │ CAPA    : Utilidades                                                   │
 * │ MÓDULO  : Venta de pasajes (factura)                                   │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Busca la razón social y la dirección de un RUC en SUNAT usando la    │
 * │   API de Decolecta. El token va en application.properties              │
 * │   (api.ruc.token). Si no hay token o internet, para un RUC 10 usa el   │
 * │   DNI que trae dentro y consulta RENIEC.                               │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.utils;

import pe.edu.upeu.syspasajes.dto.PersonaDto;

import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ConsultaRUC {

    /** Resultado de la consulta: razón social y dirección (la dirección puede venir vacía). */
    /** Resultado: razón social, dirección, estado (ACTIVO/BAJA…) y condición (HABIDO/NO HABIDO) tal como figura en SUNAT. */
    public record EmpresaDto(String razonSocial, String direccion, String estado, String condicion) {
        public EmpresaDto(String razonSocial, String direccion) {
            this(razonSocial, direccion, "", "");
        }
        /** Texto corto para mostrar: "ACTIVO · HABIDO". */
        public String situacion() {
            return (estado == null ? "" : estado) + (condicion == null || condicion.isBlank() ? "" : " · " + condicion);
        }
    }

    // Dirección de la API de SUNAT (Decolecta). Se le agrega el número de RUC al final
    private static final String URL_API = "https://api.decolecta.com/v1/sunat/ruc?numero=";

    private final ConsultaDNI consultaDNI;
    private final String token;      // se lee una sola vez de application.properties
    private HttpClient http;         // cliente HTTP de Java; se crea recién cuando se necesita

    public ConsultaRUC(ConsultaDNI consultaDNI) {
        this.consultaDNI = consultaDNI;
        this.token = leerToken();
    }

    /** Devuelve los datos del RUC o null si no se encontró (o no hay internet). */
    public EmpresaDto consultarRUC(String ruc) {
        // El RUC siempre tiene 11 números
        if (ruc == null || !ruc.matches("\\d{11}")) return null;

        // 1) Primero se pregunta a SUNAT (necesita token)
        EmpresaDto sunat = consultarApi(ruc);
        if (sunat != null) return sunat;

        // 2) Plan B para RUC 10 (persona natural): los dígitos 3 al 10 son su DNI -> RENIEC
        if (ruc.startsWith("10")) {
            PersonaDto p = consultaDNI.consultarDNI(ruc.substring(2, 10));
            if (p != null && p.getNombre() != null && !p.getNombre().isBlank()) {
                return new EmpresaDto(p.getNombre() + " " + p.getApellidoPaterno() + " " + p.getApellidoMaterno(), "");
            }
        }
        return null;
    }

    public boolean tieneToken() {
        return token != null && !token.isBlank();
    }

    /** Llama a la API: GET con el token en la cabecera "Authorization: Bearer ...". */
    private EmpresaDto consultarApi(String ruc) {
        if (!tieneToken()) return null;
        try {
            if (http == null) {
                http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(8)).build();
            }
            HttpRequest req = HttpRequest.newBuilder(URI.create(URL_API + ruc))
                    .timeout(Duration.ofSeconds(10))
                    .header("Authorization", "Bearer " + token)
                    .header("Accept", "application/json")
                    .GET()
                    .build();
            HttpResponse<String> resp = http.send(req, HttpResponse.BodyHandlers.ofString());
            // 200 = encontrado. Otro código (404 no existe, 401 token malo...) = sin datos
            if (resp.statusCode() != 200) return null;
            String razon = campoJson(resp.body(), "razon_social");
            if (razon == null || razon.isBlank()) return null;
            String dir = campoJson(resp.body(), "direccion");
            String est = campoJson(resp.body(), "estado");
            String cond = campoJson(resp.body(), "condicion");
            return new EmpresaDto(razon, dir == null ? "" : dir, est == null ? "" : est, cond == null ? "" : cond);
        } catch (Exception e) {
            return null;   // sin internet o la API no respondió
        }
    }

    /** Saca un campo de texto del JSON de respuesta, ej. "razon_social":"MI EMPRESA SAC". */
    private static String campoJson(String json, String campo) {
        Matcher m = Pattern.compile("\"" + campo + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(json);
        return m.find() ? m.group(1).replace("\\\"", "\"").trim() : null;
    }

    /** Lee api.ruc.token de application.properties. */
    private static String leerToken() {
        try (InputStream in = ConsultaRUC.class.getResourceAsStream("/application.properties")) {
            if (in == null) return "";
            Properties p = new Properties();
            p.load(in);
            return p.getProperty("api.ruc.token", "").trim();
        } catch (Exception e) {
            return "";
        }
    }
}
