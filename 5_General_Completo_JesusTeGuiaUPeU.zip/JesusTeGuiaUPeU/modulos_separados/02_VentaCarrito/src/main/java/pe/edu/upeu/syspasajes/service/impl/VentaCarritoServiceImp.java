/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VentaCarritoServiceImp.java                                  │
 * │ CAPA    : Servicio (reglas)                                            │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Reserva asientos sin duplicarlos y libera las reservas vencidas.     │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service.impl;

import pe.edu.upeu.syspasajes.model.VentaCarrito;
import pe.edu.upeu.syspasajes.model.Usuario;
import pe.edu.upeu.syspasajes.model.Viaje;
import pe.edu.upeu.syspasajes.repository.ICrudGenericoRepository;
import pe.edu.upeu.syspasajes.repository.VentaCarritoRepository;
import pe.edu.upeu.syspasajes.repository.ViajeRepository;
import pe.edu.upeu.syspasajes.service.IVentaCarritoService;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

public class VentaCarritoServiceImp extends CrudGenericoServiceImp<VentaCarrito, Long>
        implements IVentaCarritoService {

    private final VentaCarritoRepository carritoRepository;
    private final ViajeRepository viajeRepository;

    public VentaCarritoServiceImp(VentaCarritoRepository carritoRepository, ViajeRepository viajeRepository) {
        this.carritoRepository = carritoRepository;
        this.viajeRepository = viajeRepository;
    }

    @Override
    protected ICrudGenericoRepository<VentaCarrito, Long> getRepo() {
        return carritoRepository;
    }

    @Override
    public List<VentaCarrito> listaCarritoCliente(String dni) {
        return carritoRepository.listaCarritoCliente(dni);
    }

    @Override
    public void deleteCarAll(String dni) {
        carritoRepository.deleteByDni(dni);
    }

    @Override
    public synchronized List<Integer> reservarAsientos(String dni, Viaje viaje, Collection<Integer> asientos, Usuario usuario) {
        List<Integer> noReservados = new ArrayList<>();
        Set<Integer> ocupados = viajeRepository.asientosOcupados(viaje.getIdViaje());
        int capacidad = viaje.getCapacidad();
        for (Integer nro : asientos) {
            if (nro == null || nro < 1 || nro > capacidad || ocupados.contains(nro)) {
                noReservados.add(nro);
                continue;
            }
            try {
                carritoRepository.save(VentaCarrito.builder()
                        .dni(dni)
                        .viaje(viaje)
                        .nroAsiento(nro)
                        .precio(viaje.getPrecio())
                        .estado(1)
                        .idUsuario(usuario)
                        .fechaReg(LocalDateTime.now())
                        .build());
                ocupados.add(nro);
            } catch (RuntimeException e) {
                // La restricción UNIQUE(id_viaje, nro_asiento) evita reservar dos veces el mismo asiento
                noReservados.add(nro);
            }
        }
        return noReservados;
    }

    @Override
    public int liberarReservasVencidas() {
        return carritoRepository.liberarReservasVencidas(LocalDateTime.now().minusMinutes(MINUTOS_RESERVA));
    }
}
