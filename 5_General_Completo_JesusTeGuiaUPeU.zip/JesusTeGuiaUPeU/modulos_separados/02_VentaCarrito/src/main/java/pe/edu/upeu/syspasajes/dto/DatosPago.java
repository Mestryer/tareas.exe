/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : DatosPago.java                                               │
 * │ CAPA    : DTO                                                          │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Lleva del formulario al servicio el tipo de comprobante, RUC,        │
 * │   razón social, forma de pago, N° de operación y monto recibido.       │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.syspasajes.enums.MetodoPago;
import pe.edu.upeu.syspasajes.enums.TipoComprobante;

/** Datos que se piden al cobrar: comprobante (boleta/factura) y forma de pago. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DatosPago {
    private TipoComprobante tipoComprobante;
    private String ruc;
    private String razonSocial;
    private MetodoPago metodoPago;
    private String nroOperacion;
    private double montoRecibido;
}
