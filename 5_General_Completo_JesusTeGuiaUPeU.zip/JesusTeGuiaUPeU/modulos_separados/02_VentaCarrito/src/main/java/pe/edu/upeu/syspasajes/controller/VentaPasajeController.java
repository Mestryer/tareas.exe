/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : VentaPasajeController.java                                   │
 * │ CAPA    : Controlador (pantalla)                                       │
 * │ MÓDULO  : VENTA CARRITO                                                │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Vender pasaje: DNI del cliente, salida, asientos en el croquis,      │
 * │   carrito, boleta o factura (RUC automático) y forma de pago.          │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import pe.edu.upeu.syspasajes.components.*;
import pe.edu.upeu.syspasajes.dto.ComboBoxOption;
import pe.edu.upeu.syspasajes.dto.DatosPago;
import pe.edu.upeu.syspasajes.dto.ModeloDataAutocomplet;
import pe.edu.upeu.syspasajes.dto.PersonaDto;
import pe.edu.upeu.syspasajes.dto.SessionManager;
import pe.edu.upeu.syspasajes.enums.MetodoPago;
import pe.edu.upeu.syspasajes.enums.Sentido;
import pe.edu.upeu.syspasajes.enums.TipoComprobante;
import pe.edu.upeu.syspasajes.enums.TipoDocumento;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.VentaCarrito;
import pe.edu.upeu.syspasajes.model.Cliente;
import pe.edu.upeu.syspasajes.model.Usuario;
import pe.edu.upeu.syspasajes.model.VentaPasaje;
import pe.edu.upeu.syspasajes.model.Viaje;
import pe.edu.upeu.syspasajes.service.*;
import pe.edu.upeu.syspasajes.utils.ConsultaDNI;
import pe.edu.upeu.syspasajes.utils.ConsultaRUC;

import java.time.LocalDate;
import java.util.*;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * Venta de pasajes (equivale a VentaController del ejemplo).
 * Flujo: 1) cliente (DNI)  2) salida (sentido/tipo/fecha)  3) asientos
 *        4) carrito  5) comprobante (boleta/factura) + forma de pago y registrar venta.
 */
public class VentaPasajeController {

    // 1. Cliente
    @FXML TextField autocompCliente, txtDni, txtNombres, txtTelefono;
    @FXML Button btnBuscarCliente, btnRegCliente;
    // 2. Salida
    @FXML ComboBox<Sentido> cbxSentido;
    @FXML ComboBox<ComboBoxOption> cbxTipo;
    @FXML DatePicker dpFecha;
    @FXML Button btnInvertir;
    @FXML Label lblRuta;
    @FXML TableView<Viaje> tableViajes;
    // 3. Asientos
    @FXML StackPane contenedorMapa;
    @FXML Label lblViajeSel, lblSeleccion;
    @FXML Button btnRegCarrito;
    // 4. Carrito y totales
    @FXML TableView<VentaCarrito> tableView;
    @FXML TextField txtSubtotal, txtDescuento, txtBaseImp, txtIgv, txtImporteT;
    @FXML Button btnRegVenta;
    // 5. Comprobante y pago
    @FXML ComboBox<TipoComprobante> cbxComprobante;
    @FXML ComboBox<MetodoPago> cbxMetodoPago;
    @FXML TextField txtRuc, txtRazonSocial, txtNroOperacion, txtMontoRecibido, txtVuelto;
    @FXML private AnchorPane miContenedor;

    private final IClienteService ps;
    private final IViajeService vjs;
    private final IVentaCarritoService daoC;
    private final IUsuarioService daoU;
    private final IVentaPasajeService daoV;
    private final ConsultaDNI cDni;
    private final ConsultaRUC cRuc;   // búsqueda de RUC en SUNAT (factura)

    private final SortedSet<ModeloDataAutocomplet> entries =
            new TreeSet<>(Comparator.comparing(ModeloDataAutocomplet::toString));
    private AutoCompleteTextField<ModeloDataAutocomplet> actf;
    private MapaAsientos mapa;
    private Viaje viajeSel;

    public VentaPasajeController(IClienteService ps, IViajeService vjs, IVentaCarritoService daoC,
                                 IUsuarioService daoU, IVentaPasajeService daoV, ConsultaDNI cDni,
                                 ConsultaRUC cRuc) {
        this.ps = ps;
        this.vjs = vjs;
        this.daoC = daoC;
        this.daoU = daoU;
        this.daoV = daoV;
        this.cDni = cDni;
        this.cRuc = cRuc;
    }

    @FXML
    public void initialize() {
        viajeSel = null;
        daoC.liberarReservasVencidas();

        // ---------- 1. Cliente ----------
        listarClientes();
        actf = new AutoCompleteTextField<>(entries, autocompCliente);
        autocompCliente.setOnKeyReleased(e -> {
            ModeloDataAutocomplet sel = actf.getLastSelectedObject();
            if (sel != null && autocompCliente.getText().equals(sel.toString())) {
                cargarCliente(sel.getIdx());
            }
        });
        autocompCliente.setOnAction(e -> buscarCliente());
        actf.getEntryMenu().setOnHidden(e -> {
            ModeloDataAutocomplet sel = actf.getLastSelectedObject();
            if (sel != null && autocompCliente.getText().equals(sel.toString())) {
                cargarCliente(sel.getIdx());
            }
        });
        txtDni.setEditable(false);
        txtNombres.textProperty().addListener((o, a, n) -> actualizarBotonCliente());
        btnRegCliente.setDisable(true);

        // ---------- 2. Salida ----------
        cbxSentido.getItems().setAll(Sentido.values());
        cbxSentido.getSelectionModel().select(Sentido.UPEU_PLAZA);
        cbxTipo.getItems().setAll(
                new ComboBoxOption("", "Taxi y Combi"),
                new ComboBoxOption(TipoVehiculo.TAXI.name(), "Solo Taxi (4 asientos)"),
                new ComboBoxOption(TipoVehiculo.COMBI.name(), "Solo Combi (10 asientos)"));
        cbxTipo.getSelectionModel().selectFirst();
        dpFecha.setValue(LocalDate.now());
        cbxSentido.setOnAction(e -> listarViajes());
        cbxTipo.setOnAction(e -> listarViajes());
        dpFecha.setOnAction(e -> listarViajes());
        configurarTablaViajes();

        // ---------- 3. Asientos ----------
        mapa = new MapaAsientos();
        mapa.setOnCambioSeleccion(this::actualizarSeleccion);
        contenedorMapa.getChildren().setAll(mapa);

        // ---------- 4. Carrito ----------
        personalizarTabla();
        txtDescuento.setText("0.00");
        txtDescuento.textProperty().addListener((o, a, n) -> calcularTotales());
        btnRegCarrito.setDisable(true);

        // ---------- 5. Comprobante y forma de pago ----------
        cbxComprobante.getItems().setAll(TipoComprobante.values());
        cbxComprobante.getSelectionModel().select(TipoComprobante.BOLETA);
        cbxMetodoPago.getItems().setAll(MetodoPago.values());
        cbxMetodoPago.getSelectionModel().select(MetodoPago.EFECTIVO);
        cbxComprobante.setOnAction(e -> actualizarFormaPago());
        cbxMetodoPago.setOnAction(e -> actualizarFormaPago());
        txtMontoRecibido.textProperty().addListener((o, a, n) -> calcularVuelto());
        txtVuelto.setEditable(false);
        txtRuc.textProperty().addListener((o, a, n) -> {
            if (n != null && !n.matches("\\d{0,11}")) { txtRuc.setText(a); return; }
            // RUC completo: la razón social se llena sola si el RUC es conocido
            if (n != null && n.length() == 11) {
                if (!daoV.rucValido(n)) {
                    txtRuc.setStyle(ToltipCustom.ESTILO_ERROR);
                } else {
                    txtRuc.setStyle("");
                    // 1) Si ya se usó antes o es el RUC 10 de un cliente, se llena al instante
                    Optional<String> conocida = daoV.buscarRazonSocial(n);
                    if (conocida.isPresent()) {
                        txtRazonSocial.setText(conocida.get());
                    } else {
                        // 2) Si no, se consulta SUNAT por internet
                        buscarRucSunat(n);
                    }
                }
            } else {
                txtRuc.setStyle("");
            }
        });
        actualizarFormaPago();

        listarViajes();
        calcularTotales();
    }

    // =====================================================================
    //  1. PASAJERO
    // =====================================================================
    public void listarClientes() {
        entries.clear();
        entries.addAll(ps.listAutoCompletCliente());
    }

    /** Del texto "12345678 - Juan Pérez" toma solo el número. */
    private String dniDelBuscador() {
        String t = autocompCliente.getText() == null ? "" : autocompCliente.getText().trim();
        int i = t.indexOf(" - ");
        return i > 0 ? t.substring(0, i).trim() : t;
    }

    private void cargarCliente(String dni) {
        ps.buscar(dni).ifPresent(p -> {
            txtDni.setText(p.getDni());
            txtNombres.setText(p.getNombres());
            txtTelefono.setText(p.getTelefono() == null ? "" : p.getTelefono());
            btnRegCliente.setDisable(true);
            listar();
        });
    }

    @FXML
    public void buscarCliente() {
        String dni = dniDelBuscador();
        if (!dni.matches("\\d{8}")) {
            Toast.mostrar(stage(), "Ingrese un DNI válido de 8 dígitos", Toast.AVISO);
            return;
        }
        limpiarFormCliente();
        Optional<Cliente> existente = ps.buscar(dni);
        if (existente.isPresent()) {
            cargarCliente(dni);
            Toast.mostrar(stage(), "Cliente encontrado: " + existente.get().getNombres(), Toast.EXITO);
            return;
        }
        // No está registrado: se consulta RENIEC en segundo plano para no congelar la pantalla
        txtDni.setText(dni);
        listar();
        btnBuscarCliente.setDisable(true);
        btnBuscarCliente.setText("Buscando...");
        Task<PersonaDto> tarea = new Task<>() {
            @Override
            protected PersonaDto call() {
                return cDni.consultarDNI(dni);
            }
        };
        tarea.setOnSucceeded(ev -> {
            restaurarBotonBuscar();
            PersonaDto p = tarea.getValue();
            if (p != null && p.getNombre() != null && !p.getNombre().isBlank()) {
                txtNombres.setText(p.getNombre() + " " + p.getApellidoPaterno() + " " + p.getApellidoMaterno());
                Toast.mostrar(stage(), "Datos encontrados en RENIEC. Pulse \"Registrar\" para guardarlo.", Toast.INFO);
            } else {
                Toast.mostrar(stage(), "No se encontró en RENIEC. Escriba los nombres y pulse \"Registrar\".", Toast.AVISO);
                txtNombres.requestFocus();
            }
            actualizarBotonCliente();
        });
        tarea.setOnFailed(ev -> {
            restaurarBotonBuscar();
            Toast.mostrar(stage(), "Sin conexión con RENIEC. Escriba los nombres y pulse \"Registrar\".", Toast.AVISO);
            actualizarBotonCliente();
            txtNombres.requestFocus();
        });
        Thread hilo = new Thread(tarea, "consulta-dni");
        hilo.setDaemon(true);
        hilo.start();
    }

    private void restaurarBotonBuscar() {
        btnBuscarCliente.setDisable(false);
        btnBuscarCliente.setText("Buscar");
    }

    private void actualizarBotonCliente() {
        String dni = txtDni.getText() == null ? "" : txtDni.getText();
        boolean nombresOk = txtNombres.getText() != null && !txtNombres.getText().isBlank();
        boolean registrado = dni.matches("\\d{8}") && ps.buscar(dni).isPresent();
        btnRegCliente.setDisable(!(dni.matches("\\d{8}") && nombresOk && !registrado));
    }

    @FXML
    public void guardarCliente() {
        String dni = txtDni.getText();
        String nombres = txtNombres.getText() == null ? "" : txtNombres.getText().trim().toUpperCase();
        String tel = txtTelefono.getText() == null ? "" : txtTelefono.getText().trim();
        if (dni == null || !dni.matches("\\d{8}") || nombres.isEmpty()) {
            Toast.mostrar(stage(), "Complete el DNI (8 dígitos) y los nombres", Toast.AVISO);
            return;
        }
        if (!tel.isEmpty() && !tel.matches("9\\d{8}")) {
            Toast.mostrar(stage(), "El celular debe tener 9 dígitos y empezar con 9", Toast.AVISO);
            return;
        }
        try {
            ps.save(Cliente.builder()
                    .dni(dni)
                    .nombres(nombres.length() > 80 ? nombres.substring(0, 80) : nombres)
                    .telefono(tel.isEmpty() ? null : tel)
                    .tipoDocumento(TipoDocumento.DNI)
                    .build());
            txtNombres.setText(nombres);
            btnRegCliente.setDisable(true);
            listarClientes();
            Toast.mostrar(stage(), "Cliente registrado correctamente", Toast.EXITO);
            listar();
        } catch (Exception e) {
            Toast.mostrar(stage(), "Error al registrar cliente: " + e.getMessage(), Toast.ERROR);
        }
    }

    public void limpiarFormCliente() {
        txtDni.clear();
        txtNombres.clear();
        txtTelefono.clear();
        btnRegCliente.setDisable(true);
        tableView.getItems().clear();
        calcularTotales();
    }

    private boolean clienteRegistrado() {
        String dni = txtDni.getText();
        return dni != null && dni.matches("\\d{8}") && ps.buscar(dni).isPresent();
    }

    // =====================================================================
    //  2. SALIDAS
    // =====================================================================
    private void configurarTablaViajes() {
        TableViewHelper<Viaje> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Salida", new ColumnInfo("horaTexto", 65.0));
        columns.put("Vehículo", new ColumnInfo("tipoTexto", 70.0));
        columns.put("Placa", new ColumnInfo("placa", 80.0));
        columns.put("Conductor", new ColumnInfo("conductor", 165.0));
        columns.put("Libres", new ColumnInfo("libresTexto", 65.0));
        columns.put("Precio", new ColumnInfo("precioTexto", 75.0));
        helper.addColumnsInOrderWithSize(tableViajes, columns);
        tableViajes.setPlaceholder(new Label("No hay salidas programadas para este filtro"));
        tableViajes.getSelectionModel().selectedItemProperty().addListener((obs, viejo, nuevo) -> {
            viajeSel = nuevo;
            dibujarMapa();
        });
    }

    @FXML
    public void invertirSentido() {
        Sentido actual = cbxSentido.getSelectionModel().getSelectedItem();
        cbxSentido.getSelectionModel().select(actual == Sentido.UPEU_PLAZA ? Sentido.PLAZA_UPEU : Sentido.UPEU_PLAZA);
        listarViajes();
    }

    @FXML
    public void listarViajes() {
        daoC.liberarReservasVencidas();
        Sentido sentido = cbxSentido.getSelectionModel().getSelectedItem();
        LocalDate fecha = dpFecha.getValue();
        if (sentido == null || fecha == null) return;
        lblRuta.setText(sentido.getOrigen() + "   →   " + sentido.getDestino());
        ComboBoxOption tipoOp = cbxTipo.getSelectionModel().getSelectedItem();
        TipoVehiculo tipo = (tipoOp == null || tipoOp.getKey().isEmpty()) ? null : TipoVehiculo.valueOf(tipoOp.getKey());

        Long idAnterior = viajeSel == null ? null : viajeSel.getIdViaje();
        // Solo salidas que aún no partieron
        List<Viaje> lista = vjs.listarDisponibles(fecha, sentido, tipo).stream()
                .filter(v -> !v.yaPartio())
                .toList();
        tableViajes.setItems(FXCollections.observableArrayList(lista));
        // Mantiene seleccionada la misma salida después de refrescar
        if (idAnterior != null) {
            lista.stream().filter(v -> v.getIdViaje().equals(idAnterior)).findFirst()
                    .ifPresent(v -> tableViajes.getSelectionModel().select(v));
        }
        if (tableViajes.getSelectionModel().getSelectedItem() == null) {
            viajeSel = null;
            dibujarMapa();
        }
    }

    // =====================================================================
    //  3. ASIENTOS
    // =====================================================================
    private void dibujarMapa() {
        if (viajeSel == null) {
            lblViajeSel.setText("Ninguna salida seleccionada");
            mapa.mostrarMensaje("Seleccione una salida de la lista\npara ver sus asientos");
            return;
        }
        Set<Integer> ocupados = vjs.asientosOcupados(viajeSel.getIdViaje());
        lblViajeSel.setText(viajeSel.getTipoTexto() + " " + viajeSel.getPlaca() + "  |  Sale " + viajeSel.getFechaTexto()
                + " " + viajeSel.getHoraTexto() + "  |  " + viajeSel.getPrecioTexto() + " por asiento");
        mapa.dibujar(viajeSel.getVehiculo().getTipoVehiculo(), viajeSel.getCapacidad(), ocupados, viajeSel.getPlaca());
    }

    private void actualizarSeleccion() {
        if (lblSeleccion == null) return;
        Set<Integer> sel = mapa.getSeleccionados();
        if (sel.isEmpty() || viajeSel == null) {
            lblSeleccion.setText("Haga clic en los asientos verdes para elegirlos");
            btnRegCarrito.setDisable(true);
        } else {
            double importe = sel.size() * viajeSel.getPrecio();
            lblSeleccion.setText("Asiento(s): " + sel.stream().map(String::valueOf).collect(Collectors.joining(", "))
                    + "   →   " + String.format("S/ %.2f", importe));
            btnRegCarrito.setDisable(false);
        }
    }

    @FXML
    private void registarPCarrito() {
        if (!clienteRegistrado()) {
            Toast.mostrar(stage(), "Primero busque y registre al cliente (paso 1)", Toast.AVISO);
            autocompCliente.requestFocus();
            return;
        }
        if (viajeSel == null || mapa.getSeleccionados().isEmpty()) {
            Toast.mostrar(stage(), "Seleccione una salida y al menos un asiento", Toast.AVISO);
            return;
        }
        if (viajeSel.yaPartio()) {
            Toast.mostrar(stage(), "Esta salida ya partió. Elija otra.", Toast.ERROR);
            listarViajes();
            return;
        }
        try {
            Usuario usuario = daoU.findById(SessionManager.getInstance().getUserId());
            List<Integer> fallidos = daoC.reservarAsientos(txtDni.getText(), viajeSel,
                    new ArrayList<>(mapa.getSeleccionados()), usuario);
            if (fallidos.isEmpty()) {
                Toast.mostrar(stage(), "Asiento(s) agregado(s) al carrito. Reserva válida por "
                        + IVentaCarritoService.MINUTOS_RESERVA + " minutos.", Toast.EXITO);
            } else {
                Toast.mostrar(stage(), "Los asientos " + fallidos + " acaban de ser ocupados por otra venta.", Toast.AVISO);
            }
        } catch (Exception e) {
            Toast.mostrar(stage(), "Error al reservar: " + e.getMessage(), Toast.ERROR);
        }
        listar();
        listarViajes();
        dibujarMapa();
    }

    // =====================================================================
    //  4. CARRITO Y VENTA
    // =====================================================================
    public void personalizarTabla() {
        TableViewHelper<VentaCarrito> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("Asiento", new ColumnInfo("nroAsiento", 70.0));
        columns.put("Ruta", new ColumnInfo("rutaTexto", 280.0));
        columns.put("Salida", new ColumnInfo("salidaTexto", 130.0));
        columns.put("Vehículo", new ColumnInfo("vehiculoTexto", 130.0));
        columns.put("Precio", new ColumnInfo("precioTexto", 90.0));

        Consumer<VentaCarrito> updateAction = c -> Toast.mostrar(stage(),
                "Para cambiar el asiento " + c.getNroAsiento() + ", elimínelo y elija otro en el croquis.", Toast.INFO);
        Consumer<VentaCarrito> deleteAction = this::deleteReg;
        helper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        tableView.setPlaceholder(new Label("El carrito está vacío"));
        tableView.setTableMenuButtonVisible(true);
    }

    public void listar() {
        tableView.getItems().clear();
        String dni = txtDni.getText();
        if (dni != null && !dni.isBlank()) {
            tableView.getItems().addAll(daoC.listaCarritoCliente(dni));
        }
        calcularTotales();
    }

    private void calcularTotales() {
        double subtotal = tableView.getItems().stream().mapToDouble(VentaCarrito::getPrecio).sum();
        double descuento = leerDescuento();
        boolean descuentoValido = descuento >= 0 && descuento <= subtotal;
        txtDescuento.setStyle(descuentoValido ? "" : ToltipCustom.ESTILO_ERROR);
        if (!descuentoValido) descuento = 0;
        double total = redondear(subtotal - descuento);
        double base = redondear(total / (1 + IVentaPasajeService.TASA_IGV));
        txtSubtotal.setText(String.format(Locale.US, "%.2f", subtotal));
        txtImporteT.setText(String.format(Locale.US, "%.2f", total));
        txtBaseImp.setText(String.format(Locale.US, "%.2f", base));
        txtIgv.setText(String.format(Locale.US, "%.2f", redondear(total - base)));
        btnRegVenta.setDisable(tableView.getItems().isEmpty() || !descuentoValido);
        calcularVuelto();
    }

    // =====================================================================
    //  5. COMPROBANTE (BOLETA / FACTURA) Y FORMA DE PAGO
    // =====================================================================
    /** Habilita los campos según el comprobante y el método de pago elegidos. */
    private void actualizarFormaPago() {
        if (cbxComprobante == null || cbxMetodoPago == null) return;
        boolean factura = cbxComprobante.getSelectionModel().getSelectedItem() == TipoComprobante.FACTURA;
        txtRuc.setDisable(!factura);
        txtRazonSocial.setDisable(!factura);
        if (!factura) {
            txtRuc.clear();
            txtRazonSocial.clear();
        } else if ((txtRuc.getText() == null || txtRuc.getText().isBlank()) && clienteRegistrado()) {
            // Factura: se propone el RUC 10 del cliente (generado con su DNI) y su nombre como razón social
            txtRuc.setText(daoV.rucDeDni(txtDni.getText()));
            txtRazonSocial.setText(txtNombres.getText());
        }
        MetodoPago m = cbxMetodoPago.getSelectionModel().getSelectedItem();
        boolean operacion = m != null && m.isRequiereOperacion();
        txtNroOperacion.setDisable(!operacion);
        txtMontoRecibido.setDisable(operacion);
        if (operacion) {
            txtMontoRecibido.clear();
            txtNroOperacion.setPromptText(m == MetodoPago.TARJETA ? "N° voucher" : "N° de operación");
        } else {
            txtNroOperacion.clear();
        }
        calcularVuelto();
    }

    /** Consulta el RUC en SUNAT en segundo plano (para no congelar la ventana) y llena la razón social. */
    private void buscarRucSunat(String ruc) {
        txtRazonSocial.setPromptText("Consultando SUNAT...");
        Task<ConsultaRUC.EmpresaDto> tarea = new Task<>() {
            @Override
            protected ConsultaRUC.EmpresaDto call() {
                return cRuc.consultarRUC(ruc);
            }
        };
        tarea.setOnSucceeded(ev -> {
            txtRazonSocial.setPromptText("Razón social");
            ConsultaRUC.EmpresaDto e = tarea.getValue();
            // Solo se llena si el usuario no cambió el RUC mientras se consultaba
            if (e != null && ruc.equals(txtRuc.getText())) {
                txtRazonSocial.setText(e.razonSocial());
                Toast.mostrar(stage(), "SUNAT: " + e.razonSocial() + (e.situacion().isBlank() ? "" : " (" + e.situacion() + ")"), Toast.EXITO);
            } else if (e == null) {
                Toast.mostrar(stage(), "No se encontró el RUC en SUNAT. Escriba la razón social.", Toast.AVISO);
            }
        });
        tarea.setOnFailed(ev -> txtRazonSocial.setPromptText("Razón social"));
        Thread hilo = new Thread(tarea, "consulta-ruc");
        hilo.setDaemon(true);
        hilo.start();
    }

    private void calcularVuelto() {
        if (txtVuelto == null || txtImporteT == null) return;
        MetodoPago m = cbxMetodoPago == null ? null : cbxMetodoPago.getSelectionModel().getSelectedItem();
        if (m != null && m.isRequiereOperacion()) {
            txtVuelto.setText("0.00");
            txtMontoRecibido.setStyle("");
            return;
        }
        double total = parse(txtImporteT.getText());
        double recibido = parse(txtMontoRecibido.getText());
        boolean vacio = txtMontoRecibido.getText() == null || txtMontoRecibido.getText().isBlank();
        boolean ok = vacio || recibido >= total;
        txtMontoRecibido.setStyle(ok ? "" : ToltipCustom.ESTILO_ERROR);
        txtVuelto.setText(!vacio && recibido >= total ? String.format(Locale.US, "%.2f", redondear(recibido - total)) : "0.00");
    }

    private static double parse(String t) {
        if (t == null || t.isBlank()) return 0;
        try {
            return Double.parseDouble(t.trim().replace(",", "."));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** Lee el formulario de pago; devuelve null (y avisa) si falta algo. */
    private DatosPago leerDatosPago() {
        TipoComprobante tipo = cbxComprobante.getSelectionModel().getSelectedItem();
        MetodoPago metodo = cbxMetodoPago.getSelectionModel().getSelectedItem();
        if (tipo == null || metodo == null) {
            Toast.mostrar(stage(), "Elija el comprobante y la forma de pago", Toast.AVISO);
            return null;
        }
        String ruc = txtRuc.getText() == null ? "" : txtRuc.getText().trim();
        String razon = txtRazonSocial.getText() == null ? "" : txtRazonSocial.getText().trim();
        if (tipo == TipoComprobante.FACTURA) {
            if (!daoV.rucValido(ruc)) {
                Toast.mostrar(stage(), "RUC no válido: 11 dígitos, empieza con 10 o 20 y el último dígito debe cuadrar", Toast.AVISO);
                txtRuc.requestFocus();
                return null;
            }
            if (razon.isEmpty()) {
                Toast.mostrar(stage(), "Para factura escriba la razón social", Toast.AVISO);
                txtRazonSocial.requestFocus();
                return null;
            }
        }
        String operacion = txtNroOperacion.getText() == null ? "" : txtNroOperacion.getText().trim();
        double recibido = parse(txtMontoRecibido.getText());
        double total = parse(txtImporteT.getText());
        if (metodo.isRequiereOperacion()) {
            if (!operacion.matches("[A-Za-z0-9-]{4,30}")) {
                Toast.mostrar(stage(), "Escriba el N° de operación de " + metodo.getDescripcion(), Toast.AVISO);
                txtNroOperacion.requestFocus();
                return null;
            }
        } else {
            if (txtMontoRecibido.getText() == null || txtMontoRecibido.getText().isBlank()) {
                recibido = total; // pago exacto
            } else if (recibido < total) {
                Toast.mostrar(stage(), "El monto recibido es menor que el total", Toast.AVISO);
                txtMontoRecibido.requestFocus();
                return null;
            }
        }
        return DatosPago.builder()
                .tipoComprobante(tipo)
                .ruc(ruc)
                .razonSocial(razon)
                .metodoPago(metodo)
                .nroOperacion(operacion)
                .montoRecibido(recibido)
                .build();
    }

    private double leerDescuento() {
        String t = txtDescuento.getText();
        if (t == null || t.isBlank()) return 0;
        try {
            return Double.parseDouble(t.trim().replace(",", "."));
        } catch (NumberFormatException e) {
            return -1; // inválido
        }
    }

    public void deleteReg(VentaCarrito obj) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Confirmación");
        alert.setHeaderText("Quitar asiento del carrito");
        alert.setContentText("¿Desea liberar el asiento " + obj.getNroAsiento() + " de la salida "
                + obj.getSalidaTexto() + "?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                daoC.delete(obj.getIdCarrito());
                Toast.mostrar(stage(), "Asiento " + obj.getNroAsiento() + " liberado", Toast.EXITO);
            } catch (Exception e) {
                Toast.mostrar(stage(), "La reserva ya no existe (venció)", Toast.AVISO);
            }
            listar();
            listarViajes();
            dibujarMapa();
        }
    }

    @FXML
    public void registrarVenta() {
        if (!clienteRegistrado()) {
            Toast.mostrar(stage(), "Seleccione un cliente registrado", Toast.AVISO);
            return;
        }
        double descuento = leerDescuento();
        if (descuento < 0) {
            Toast.mostrar(stage(), "El descuento no es válido", Toast.ERROR);
            return;
        }
        DatosPago pago = leerDatosPago();
        if (pago == null) return;
        try {
            VentaPasaje venta = daoV.registrarVenta(txtDni.getText(), SessionManager.getInstance().getUserId(), descuento, pago);
            mostrarBoleta(venta);
            limpiarTodo();
        } catch (Exception e) {
            Toast.mostrar(stage(), "No se registró la venta: " + e.getMessage(), Toast.ERROR);
            listar();
            listarViajes();
            dibujarMapa();
        }
    }

    /** Boleta/factura con botones Imprimir y WhatsApp al taxista (ver components/DialogoComprobante). */
    private void mostrarBoleta(VentaPasaje venta) {
        pe.edu.upeu.syspasajes.utils.AvisoTaxista.enviarAutomatico(venta);   // WhatsApp al taxista con la reserva y el pago
        DialogoComprobante.mostrar(venta, daoV.generarTextoBoleta(venta), "Venta registrada",
                (venta.esFactura() ? "Factura " : "Boleta ") + venta.getSerie() + "-" + venta.getNumDoc()
                        + " generada correctamente", stage());
    }

    @FXML
    public void limpiarTodo() {
        autocompCliente.clear();
        limpiarFormCliente();
        txtDescuento.setText("0.00");
        cbxComprobante.getSelectionModel().select(TipoComprobante.BOLETA);
        cbxMetodoPago.getSelectionModel().select(MetodoPago.EFECTIVO);
        actualizarFormaPago();
        listarViajes();
        dibujarMapa();
        calcularTotales();
        Platform.runLater(() -> autocompCliente.requestFocus());
    }

    private static double redondear(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    private Stage stage() {
        if (miContenedor != null && miContenedor.getScene() != null) {
            return (Stage) miContenedor.getScene().getWindow();
        }
        return StageManager.getPrimaryStage();
    }
}
