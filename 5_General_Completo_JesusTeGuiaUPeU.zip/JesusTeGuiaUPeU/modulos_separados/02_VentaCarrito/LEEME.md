# Módulo VentaCarrito — SysPasajes UPeU v3 (azul, blanco y dorado)

Carrito de asientos reservados (15 min) y la venta. Novedad v3: cada venta avisa al taxista (tabla `notificacion` + botón WhatsApp) y la boleta/factura se puede imprimir.

Venta: DNI obligatorio, boleta o factura (RUC), formas de pago Efectivo/Yape/Plin/Tarjeta/Transferencia con N° de operación o vuelto.

## Archivos (capas Model → Repository → Service → Controller → View)
- `model/VentaCarrito.java`
- `repository/VentaCarritoRepository.java`
- `service/IVentaCarritoService.java`
- `service/impl/VentaCarritoServiceImp.java`
- `controller/VentaCarritoController.java`
- `model/VentaPasaje.java`
- `model/Boleto.java`
- `dto/DatosPago.java`
- `enums/MetodoPago.java`
- `enums/TipoComprobante.java`
- `repository/VentaPasajeRepository.java`
- `service/IVentaPasajeService.java`
- `service/impl/VentaPasajeServiceImp.java`
- `controller/VentaPasajeController.java`
- `utils/AvisoTaxista.java` (NUEVO: mensaje de reserva de asiento al taxista + WhatsApp)
- `components/DialogoComprobante.java` (NUEVO: boleta/factura con botones Imprimir y WhatsApp)
- `view/main_carrito.fxml`
- `view/main_venta.fxml`
- `tabla.sql` (tabla(s) H2 del módulo)

## Cómo se conecta
Estos archivos son una copia del proyecto general `SysPasajesUPeU`, separados para revisarlos por módulo.
Para que compilen necesitan el resto del proyecto (AppContext, SqlHelper, AbstractJpaRepository, TableViewHelper,
Toast...). En el proyecto general ya están registrados en `config/AppContext.java` y en el menú
(`service/impl/MenuMenuItemDaoImp.java`).
