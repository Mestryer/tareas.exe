# Módulo Producto — SysPasajes UPeU v3 (azul, blanco y dorado)

Productos = tarifas del pasaje (tipo de vehículo + sentido + precio). Al cambiar un precio se puede aplicar a las salidas futuras.

Tarifas por tipo de vehículo: Auto de 5 asientos (4 pasajeros) y Van de 11 asientos (10 pasajeros) — ver `enums/TipoVehiculo.java`.

## Archivos (capas Model → Repository → Service → Controller → View)
- `model/Producto.java`
- `repository/ProductoRepository.java`
- `service/IProductoService.java`
- `service/impl/ProductoServiceImp.java`
- `controller/ProductoController.java`
- `view/main_producto.fxml`
- `tabla.sql` (tabla(s) H2 del módulo)

## Cómo se conecta
Estos archivos son una copia del proyecto general `SysPasajesUPeU`, separados para revisarlos por módulo.
Para que compilen necesitan el resto del proyecto (AppContext, SqlHelper, AbstractJpaRepository, TableViewHelper,
Toast...). En el proyecto general ya están registrados en `config/AppContext.java` y en el menú
(`service/impl/MenuMenuItemDaoImp.java`).
