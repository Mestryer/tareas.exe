/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : Producto.java                                                │
 * │ CAPA    : Modelo (datos)                                               │
 * │ MÓDULO  : PRODUCTO                                                     │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Tarifa del pasaje: tipo de vehículo + sentido + precio.              │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.model;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import pe.edu.upeu.syspasajes.enums.Sentido;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;

/**
 * MÓDULO PRODUCTO: lo que se vende es el pasaje. Cada producto es una tarifa:
 * tipo de vehículo + sentido de la ruta + precio. Al programar una salida
 * se usa el precio del producto que le corresponde.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Producto {

    private Long idProducto;

    @NotBlank(message = "El nombre del producto es obligatorio")
    @Size(max = 60, message = "El nombre admite máximo 60 caracteres")
    private String nombre;

    @NotNull(message = "Debe elegir el tipo de vehículo")
    private TipoVehiculo tipoVehiculo;

    @NotNull(message = "Debe elegir el sentido de la ruta")
    private Sentido sentido;

    @NotNull(message = "El precio es obligatorio")
    @Positive(message = "El precio debe ser mayor a cero")
    private Double precio;

    @Size(max = 120, message = "La descripción admite máximo 120 caracteres")
    private String descripcion;

    @NotBlank(message = "El estado es obligatorio")
    private String estado;

    public String getTipoTexto() {
        return tipoVehiculo == null ? "" : tipoVehiculo.getDescripcion();
    }

    public String getSentidoTexto() {
        return sentido == null ? "" : sentido.getDescripcion();
    }

    public String getPrecioTexto() {
        return String.format("S/ %.2f", precio == null ? 0.0 : precio);
    }

    @Override
    public String toString() {
        return nombre + " (" + getPrecioTexto() + ")";
    }
}
