/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : ProductoController.java                                      │
 * │ CAPA    : Controlador (pantalla)                                       │
 * │ MÓDULO  : PRODUCTO                                                     │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Pantalla Productos: tarifas del pasaje por tipo de vehículo y        │
 * │   sentido; puede aplicar el nuevo precio a las salidas futuras.        │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.controller;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validation;
import jakarta.validation.Validator;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import pe.edu.upeu.syspasajes.components.ColumnInfo;
import pe.edu.upeu.syspasajes.components.TableViewHelper;
import pe.edu.upeu.syspasajes.components.Toast;
import pe.edu.upeu.syspasajes.components.ToltipCustom;
import pe.edu.upeu.syspasajes.enums.Sentido;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Producto;
import pe.edu.upeu.syspasajes.service.IProductoService;

import java.util.*;
import java.util.function.Consumer;

/** MÓDULO PRODUCTO - CRUD de productos (tarifas del pasaje). */
public class ProductoController {

    private final IProductoService ps;

    @FXML TextField txtNombre, txtPrecio, txtDescripcion, txtFiltroDato;
    @FXML ComboBox<TipoVehiculo> cbxTipo;
    @FXML ComboBox<Sentido> cbxSentido;
    @FXML ComboBox<String> cbxEstado;
    @FXML CheckBox chkAplicar;
    @FXML Label lbnMsg;
    @FXML Button btnGuardar;
    @FXML private TableView<Producto> tableView;
    @FXML private AnchorPane miContenedor;

    private Validator validator;
    private final ToltipCustom ttc = new ToltipCustom();
    private List<Producto> lista = new ArrayList<>();
    private Long idProductoCE = 0L;

    public ProductoController(IProductoService ps) {
        this.ps = ps;
    }

    @FXML
    public void initialize() {
        idProductoCE = 0L;
        validator = Validation.buildDefaultValidatorFactory().getValidator();
        cbxTipo.getItems().setAll(TipoVehiculo.values());
        cbxSentido.getItems().setAll(Sentido.values());
        cbxEstado.getItems().setAll("ACTIVO", "INACTIVO");
        cbxEstado.getSelectionModel().select("ACTIVO");
        chkAplicar.setSelected(true);
        txtFiltroDato.textProperty().addListener((o, a, n) -> filtrar());
        // Nombre sugerido al elegir tipo y sentido
        cbxTipo.setOnAction(e -> sugerirNombre());
        cbxSentido.setOnAction(e -> sugerirNombre());

        TableViewHelper<Producto> helper = new TableViewHelper<>();
        LinkedHashMap<String, ColumnInfo> columns = new LinkedHashMap<>();
        columns.put("ID", new ColumnInfo("idProducto", 50.0));
        columns.put("Producto", new ColumnInfo("nombre", 210.0));
        columns.put("Vehículo", new ColumnInfo("tipoTexto", 80.0));
        columns.put("Sentido", new ColumnInfo("sentidoTexto", 260.0));
        columns.put("Precio", new ColumnInfo("precioTexto", 80.0));
        columns.put("Estado", new ColumnInfo("estado", 85.0));
        Consumer<Producto> updateAction = this::editForm;
        Consumer<Producto> deleteAction = p -> {
            if (!confirmar("¿Eliminar el producto " + p.getNombre() + "?")) return;
            try {
                ps.delete(p.getIdProducto());
                Toast.mostrar(stage(), "Producto eliminado correctamente", Toast.EXITO);
                if (Objects.equals(idProductoCE, p.getIdProducto())) clearForm();
            } catch (Exception ex) {
                Toast.mostrar(stage(), "No se puede eliminar: " + ex.getMessage(), Toast.ERROR);
            }
            listar();
        };
        helper.addColumnsInOrderWithSize(tableView, columns, updateAction, deleteAction);
        tableView.setPlaceholder(new Label("No hay productos registrados"));
        lbnMsg.setText("");
        listar();
    }

    public void listar() {
        lista = ps.findAll();
        filtrar();
    }

    private void filtrar() {
        String f = txtFiltroDato.getText() == null ? "" : txtFiltroDato.getText().trim().toLowerCase();
        tableView.setItems(FXCollections.observableArrayList(lista.stream()
                .filter(p -> f.isEmpty() || p.getNombre().toLowerCase().contains(f)
                        || p.getTipoTexto().toLowerCase().contains(f)
                        || p.getSentidoTexto().toLowerCase().contains(f))
                .toList()));
    }

    private void sugerirNombre() {
        TipoVehiculo t = cbxTipo.getSelectionModel().getSelectedItem();
        Sentido s = cbxSentido.getSelectionModel().getSelectedItem();
        if (t != null && s != null && (txtNombre.getText() == null || txtNombre.getText().isBlank())) {
            String corto = s == Sentido.UPEU_PLAZA ? "UPeU → Plaza" : "Plaza → UPeU";
            txtNombre.setText("Pasaje " + t.getDescripcion() + " " + corto);
        }
    }

    @FXML
    public void validarFormulario() {
        limpiarError();
        String desc = txt(txtDescripcion);
        Producto formulario = Producto.builder()
                .nombre(txt(txtNombre))
                .tipoVehiculo(cbxTipo.getSelectionModel().getSelectedItem())
                .sentido(cbxSentido.getSelectionModel().getSelectedItem())
                .precio(leerPrecio())
                .descripcion(desc.isEmpty() ? null : desc)
                .estado(cbxEstado.getSelectionModel().getSelectedItem())
                .build();
        List<ConstraintViolation<Producto>> errores = new ArrayList<>(validator.validate(formulario));
        errores.sort(Comparator.comparing(v -> v.getPropertyPath().toString()));
        if (!errores.isEmpty()) {
            ConstraintViolation<Producto> e = errores.get(0);
            Control c = switch (e.getPropertyPath().toString()) {
                case "tipoVehiculo" -> cbxTipo;
                case "sentido" -> cbxSentido;
                case "precio" -> txtPrecio;
                case "descripcion" -> txtDescripcion;
                case "estado" -> cbxEstado;
                default -> txtNombre;
            };
            error(c, e.getMessage());
            return;
        }
        try {
            if (idProductoCE > 0L) {
                formulario.setIdProducto(idProductoCE);
                ps.update(idProductoCE, formulario);
            } else {
                ps.save(formulario);
            }
            String extra = "";
            if (chkAplicar.isSelected()) {
                int n = ps.aplicarPrecioASalidasFuturas(formulario);
                extra = " · " + n + " salida(s) futura(s) con el nuevo precio";
            }
            Toast.mostrar(stage(), "Producto guardado" + extra, Toast.EXITO);
            clearForm();
            lbnMsg.setText("Formulario guardado" + extra);
            lbnMsg.setStyle("-fx-text-fill: #1553c7; -fx-font-size: 14px;");
            listar();
        } catch (Exception ex) {
            lbnMsg.setText("Error al guardar: " + ex.getMessage());
            lbnMsg.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 14px;");
        }
    }

    private Double leerPrecio() {
        String t = txtPrecio.getText();
        if (t == null || t.isBlank()) return null;
        try {
            return Math.round(Double.parseDouble(t.trim().replace(",", ".")) * 100.0) / 100.0;
        } catch (NumberFormatException e) {
            return -1.0; // la validación @Positive lo marca como error
        }
    }

    public void editForm(Producto p) {
        limpiarError();
        idProductoCE = p.getIdProducto();
        txtNombre.setText(p.getNombre());
        cbxTipo.getSelectionModel().select(p.getTipoVehiculo());
        cbxSentido.getSelectionModel().select(p.getSentido());
        txtPrecio.setText(String.format(Locale.US, "%.2f", p.getPrecio()));
        txtDescripcion.setText(p.getDescripcion() == null ? "" : p.getDescripcion());
        cbxEstado.getSelectionModel().select(p.getEstado());
        btnGuardar.setText("Actualizar");
        lbnMsg.setText("Editando producto " + p.getNombre());
        lbnMsg.setStyle("-fx-text-fill: #1565c0; -fx-font-size: 14px;");
    }

    @FXML
    public void clearForm() {
        txtNombre.clear();
        txtPrecio.clear();
        txtDescripcion.clear();
        cbxTipo.getSelectionModel().clearSelection();
        cbxSentido.getSelectionModel().clearSelection();
        cbxEstado.getSelectionModel().select("ACTIVO");
        idProductoCE = 0L;
        btnGuardar.setText("Guardar");
        lbnMsg.setText("");
        limpiarError();
    }

    private void error(Control c, String msg) {
        ttc.marcarError(c, msg);
        lbnMsg.setText(msg);
        lbnMsg.setStyle("-fx-text-fill: #d32f2f; -fx-font-size: 14px;");
        Platform.runLater(c::requestFocus);
    }

    private void limpiarError() {
        List.of(txtNombre, cbxTipo, cbxSentido, txtPrecio, txtDescripcion, cbxEstado).forEach(ttc::limpiarCampo);
    }

    private String txt(TextField tf) {
        return tf.getText() == null ? "" : tf.getText().trim();
    }

    private boolean confirmar(String mensaje) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION, mensaje, ButtonType.OK, ButtonType.CANCEL);
        alert.setTitle("Confirmación");
        alert.setHeaderText(null);
        return alert.showAndWait().filter(b -> b == ButtonType.OK).isPresent();
    }

    private Stage stage() {
        return (Stage) miContenedor.getScene().getWindow();
    }
}
