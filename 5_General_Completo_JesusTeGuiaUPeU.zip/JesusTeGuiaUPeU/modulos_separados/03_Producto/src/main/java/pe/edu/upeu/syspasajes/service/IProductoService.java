/* ┌────────────────────────────────────────────────────────────────────────┐
 * │ ARCHIVO : IProductoService.java                                        │
 * │ CAPA    : Servicio (interfaz)                                          │
 * │ MÓDULO  : PRODUCTO                                                     │
 * │ ¿PARA QUÉ SIRVE?                                                       │
 * │   Qué se puede hacer con productos: CRUD, precio por tipo y sentido,   │
 * │   aplicar precio.                                                      │
 * │ Proyecto: Jesús te guía a la UPeU                                      │
 * └────────────────────────────────────────────────────────────────────────┘ */
package pe.edu.upeu.syspasajes.service;

import pe.edu.upeu.syspasajes.enums.Sentido;
import pe.edu.upeu.syspasajes.enums.TipoVehiculo;
import pe.edu.upeu.syspasajes.model.Producto;

import java.util.List;

/** MÓDULO PRODUCTO - reglas de negocio de las tarifas. */
public interface IProductoService extends ICrudGenericoService<Producto, Long> {
    List<Producto> listarActivos();
    /** Precio del pasaje para un tipo de vehículo y sentido (si no hay producto, el precio sugerido del tipo). */
    double precioPara(TipoVehiculo tipo, Sentido sentido);
    /** Actualiza el precio de las salidas futuras de ese producto. Devuelve cuántas salidas cambiaron. */
    int aplicarPrecioASalidasFuturas(Producto producto);
}
