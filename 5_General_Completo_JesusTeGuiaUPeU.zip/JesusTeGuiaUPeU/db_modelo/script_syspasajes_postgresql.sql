-- =====================================================================
--  SysPasajes UPeU - Venta de pasajes Taxi & Combi
--  Ruta: Universidad UPeU <-> C.C. Plaza de Armas
--  Script para PostgreSQL (mismo estilo que script_sysventas.sql del ejemplo)
--
--  Contenido:
--    1. Creación de tablas (secuencias, PK, FK, UNIQUE y CHECK)
--    2. Datos iniciales (perfiles, usuario Ronaldo, vehículos, salidas)
--    3. Venta de ejemplo (cliente + carrito + boleta + boletos)
--    4. DML de ejemplo (C, R, U, D) como en dmls.sql del profesor
--    5. Consultas / reportes
--
--  Taxi  = 4 asientos  (chofer + copiloto + 3 atrás)
--  Combi = 10 asientos (chofer + 2 adelante + 8 atrás)
-- =====================================================================

-- Para volver a ejecutar el script desde cero (descomentar):
-- DROP TABLE IF EXISTS public.boleto, public.venta_pasaje, public.venta_carrito,
--     public.cliente, public.viaje, public.vehiculo, public.usuario, public.perfil CASCADE;


-- =====================================================================
-- 1. TABLAS
-- =====================================================================

CREATE SEQUENCE public.perfil_id_perfil_seq;

CREATE TABLE public.perfil (
                id_perfil INTEGER NOT NULL DEFAULT nextval('public.perfil_id_perfil_seq'),
                nombre VARCHAR(20) NOT NULL,
                codigo VARCHAR(60) NOT NULL,
                CONSTRAINT perfil_pk PRIMARY KEY (id_perfil)
);

ALTER SEQUENCE public.perfil_id_perfil_seq OWNED BY public.perfil.id_perfil;


CREATE SEQUENCE public.usuario_id_usuario_seq;

CREATE TABLE public.usuario (
                id_usuario INTEGER NOT NULL DEFAULT nextval('public.usuario_id_usuario_seq'),
                usuario VARCHAR(20) NOT NULL,
                clave VARCHAR(60) NOT NULL,
                estado VARCHAR(10) NOT NULL,
                id_perfil INTEGER NOT NULL,
                CONSTRAINT usuario_pk PRIMARY KEY (id_usuario),
                CONSTRAINT usuario_usuario_uk UNIQUE (usuario)
);

ALTER SEQUENCE public.usuario_id_usuario_seq OWNED BY public.usuario.id_usuario;


-- Flota: taxis y combis
CREATE SEQUENCE public.vehiculo_id_vehiculo_seq;

CREATE TABLE public.vehiculo (
                id_vehiculo INTEGER NOT NULL DEFAULT nextval('public.vehiculo_id_vehiculo_seq'),
                placa VARCHAR(10) NOT NULL,
                tipo_vehiculo VARCHAR(10) NOT NULL,
                marca_modelo VARCHAR(40) NOT NULL,
                conductor VARCHAR(60) NOT NULL,
                color VARCHAR(20) NOT NULL,
                asientos INTEGER NOT NULL,
                estado VARCHAR(10) NOT NULL,
                CONSTRAINT vehiculo_pk PRIMARY KEY (id_vehiculo),
                CONSTRAINT vehiculo_placa_uk UNIQUE (placa),
                CONSTRAINT vehiculo_tipo_ck CHECK (
                    (tipo_vehiculo = 'TAXI'  AND asientos = 4) OR
                    (tipo_vehiculo = 'COMBI' AND asientos = 10)),
                CONSTRAINT vehiculo_estado_ck CHECK (estado IN ('ACTIVO', 'INACTIVO'))
);

ALTER SEQUENCE public.vehiculo_id_vehiculo_seq OWNED BY public.vehiculo.id_vehiculo;


-- Salidas programadas (lo que se vende)
CREATE SEQUENCE public.viaje_id_viaje_seq;

CREATE TABLE public.viaje (
                id_viaje INTEGER NOT NULL DEFAULT nextval('public.viaje_id_viaje_seq'),
                id_vehiculo INTEGER NOT NULL,
                sentido VARCHAR(20) NOT NULL,
                fecha DATE NOT NULL,
                hora_salida TIME NOT NULL,
                precio DOUBLE PRECISION NOT NULL,
                estado VARCHAR(15) NOT NULL,
                CONSTRAINT viaje_pk PRIMARY KEY (id_viaje),
                CONSTRAINT viaje_sentido_ck CHECK (sentido IN ('UPEU_PLAZA', 'PLAZA_UPEU')),
                CONSTRAINT viaje_estado_ck CHECK (estado IN ('PROGRAMADO', 'EN_RUTA', 'FINALIZADO', 'CANCELADO')),
                CONSTRAINT viaje_precio_ck CHECK (precio > 0)
);

ALTER SEQUENCE public.viaje_id_viaje_seq OWNED BY public.viaje.id_viaje;


-- Cliente (cliente)
CREATE TABLE public.cliente (
                dni VARCHAR(12) NOT NULL,
                nombres VARCHAR(80) NOT NULL,
                telefono VARCHAR(15),
                tipo_documento VARCHAR(12) NOT NULL,
                CONSTRAINT cliente_pk PRIMARY KEY (dni)
);


-- Carrito: reserva temporal (15 min) de asientos antes de pagar
CREATE SEQUENCE public.venta_carrito_id_carrito_seq;

CREATE TABLE public.venta_carrito (
                id_carrito INTEGER NOT NULL DEFAULT nextval('public.venta_carrito_id_carrito_seq'),
                dni VARCHAR(12) NOT NULL,
                id_viaje INTEGER NOT NULL,
                nro_asiento INTEGER NOT NULL,
                precio DOUBLE PRECISION NOT NULL,
                estado INTEGER NOT NULL,
                id_usuario INTEGER NOT NULL,
                fecha_reg TIMESTAMP NOT NULL,
                CONSTRAINT venta_carrito_pk PRIMARY KEY (id_carrito),
                CONSTRAINT uq_carrito_asiento UNIQUE (id_viaje, nro_asiento),
                CONSTRAINT carrito_asiento_ck CHECK (nro_asiento BETWEEN 1 AND 10)
);

ALTER SEQUENCE public.venta_carrito_id_carrito_seq OWNED BY public.venta_carrito.id_carrito;


-- Venta (cabecera de la boleta)
CREATE SEQUENCE public.venta_pasaje_id_venta_seq;

CREATE TABLE public.venta_pasaje (
                id_venta INTEGER NOT NULL DEFAULT nextval('public.venta_pasaje_id_venta_seq'),
                precio_base DOUBLE PRECISION NOT NULL,
                igv DOUBLE PRECISION NOT NULL,
                descuento DOUBLE PRECISION NOT NULL,
                precio_total DOUBLE PRECISION NOT NULL,
                serie VARCHAR(10) NOT NULL,
                num_doc VARCHAR(12) NOT NULL,
                tipo_doc VARCHAR(20) NOT NULL,
                fecha_venta TIMESTAMP NOT NULL,
                dni VARCHAR(12) NOT NULL,
                id_usuario INTEGER NOT NULL,
                CONSTRAINT venta_pasaje_pk PRIMARY KEY (id_venta)
);

ALTER SEQUENCE public.venta_pasaje_id_venta_seq OWNED BY public.venta_pasaje.id_venta;


-- Boleto (detalle): un registro por asiento vendido
CREATE SEQUENCE public.boleto_id_boleto_seq;

CREATE TABLE public.boleto (
                id_boleto INTEGER NOT NULL DEFAULT nextval('public.boleto_id_boleto_seq'),
                id_venta INTEGER NOT NULL,
                id_viaje INTEGER NOT NULL,
                nro_asiento INTEGER NOT NULL,
                precio DOUBLE PRECISION NOT NULL,
                CONSTRAINT boleto_pk PRIMARY KEY (id_boleto),
                CONSTRAINT uq_boleto_asiento UNIQUE (id_viaje, nro_asiento),
                CONSTRAINT boleto_asiento_ck CHECK (nro_asiento BETWEEN 1 AND 10)
);

ALTER SEQUENCE public.boleto_id_boleto_seq OWNED BY public.boleto.id_boleto;


-- ---------------- Llaves foráneas ----------------
ALTER TABLE public.usuario ADD CONSTRAINT perfil_usuario_fk
FOREIGN KEY (id_perfil) REFERENCES public.perfil (id_perfil)
ON DELETE NO ACTION ON UPDATE NO ACTION NOT DEFERRABLE;

ALTER TABLE public.viaje ADD CONSTRAINT vehiculo_viaje_fk
FOREIGN KEY (id_vehiculo) REFERENCES public.vehiculo (id_vehiculo)
ON DELETE NO ACTION ON UPDATE NO ACTION NOT DEFERRABLE;

ALTER TABLE public.venta_carrito ADD CONSTRAINT viaje_venta_carrito_fk
FOREIGN KEY (id_viaje) REFERENCES public.viaje (id_viaje)
ON DELETE NO ACTION ON UPDATE NO ACTION NOT DEFERRABLE;

ALTER TABLE public.venta_carrito ADD CONSTRAINT usuario_venta_carrito_fk
FOREIGN KEY (id_usuario) REFERENCES public.usuario (id_usuario)
ON DELETE NO ACTION ON UPDATE NO ACTION NOT DEFERRABLE;

ALTER TABLE public.venta_pasaje ADD CONSTRAINT cliente_venta_pasaje_fk
FOREIGN KEY (dni) REFERENCES public.cliente (dni)
ON DELETE NO ACTION ON UPDATE NO ACTION NOT DEFERRABLE;

ALTER TABLE public.venta_pasaje ADD CONSTRAINT usuario_venta_pasaje_fk
FOREIGN KEY (id_usuario) REFERENCES public.usuario (id_usuario)
ON DELETE NO ACTION ON UPDATE NO ACTION NOT DEFERRABLE;

ALTER TABLE public.boleto ADD CONSTRAINT venta_pasaje_boleto_fk
FOREIGN KEY (id_venta) REFERENCES public.venta_pasaje (id_venta)
ON DELETE NO ACTION ON UPDATE NO ACTION NOT DEFERRABLE;

ALTER TABLE public.boleto ADD CONSTRAINT viaje_boleto_fk
FOREIGN KEY (id_viaje) REFERENCES public.viaje (id_viaje)
ON DELETE NO ACTION ON UPDATE NO ACTION NOT DEFERRABLE;


-- =====================================================================
-- 2. DATOS INICIALES
-- =====================================================================

INSERT INTO public.perfil (nombre, codigo) VALUES
    ('Root', 'ROOT'),
    ('Administrador', 'ADM'),
    ('Reporte', 'REP');

-- Usuario de acceso: Ronaldo / 1234567 (perfil Root)
INSERT INTO public.usuario (usuario, clave, estado, id_perfil)
SELECT 'Ronaldo', '1234567', 'ACTIVO', id_perfil FROM public.perfil WHERE codigo = 'ROOT';

-- Flota: 4 vehiculos = 2 autos de 5 asientos (4 pasajeros) y 2 vans de 11 asientos (10 pasajeros)
INSERT INTO public.vehiculo (placa, tipo_vehiculo, marca_modelo, conductor, color, asientos, estado) VALUES
    ('TAX-101', 'TAXI',  'Toyota Yaris',   'Mijael Jaret Quispe Vargas',    'Azul',   4,  'ACTIVO'),
    ('TAX-202', 'TAXI',  'Hyundai Accent', 'Alvaro Layme Urviola',          'Blanco', 4,  'ACTIVO'),
    ('CMB-410', 'COMBI', 'Toyota Hiace',   'Heans Gary Livisi Huaynasi',    'Blanco', 10, 'ACTIVO'),
    ('CMB-520', 'COMBI', 'Nissan Urvan',   'Ronaldo Pablo Sucasaca Mamani', 'Azul',   10, 'ACTIVO');

-- Salidas de HOY en ambos sentidos (taxi S/ 3.00, combi S/ 1.50 por asiento)
INSERT INTO public.viaje (id_vehiculo, sentido, fecha, hora_salida, precio, estado)
SELECT v.id_vehiculo, s.sentido, CURRENT_DATE, s.hora::TIME,
       CASE v.tipo_vehiculo WHEN 'TAXI' THEN 3.00 ELSE 1.50 END, 'PROGRAMADO'
FROM (VALUES
        ('TAX-101', 'UPEU_PLAZA', '07:00'), ('TAX-202', 'PLAZA_UPEU', '07:00'),
        ('TAX-202', 'UPEU_PLAZA', '09:00'), ('TAX-101', 'PLAZA_UPEU', '09:00'),
        ('TAX-202', 'UPEU_PLAZA', '11:00'), ('TAX-101', 'PLAZA_UPEU', '11:00'),
        ('TAX-101', 'UPEU_PLAZA', '13:00'), ('TAX-202', 'PLAZA_UPEU', '13:00'),
        ('TAX-202', 'UPEU_PLAZA', '17:00'), ('TAX-101', 'PLAZA_UPEU', '17:00'),
        ('TAX-202', 'UPEU_PLAZA', '19:00'), ('TAX-101', 'PLAZA_UPEU', '19:00'),
        ('CMB-410', 'UPEU_PLAZA', '06:30'), ('CMB-520', 'PLAZA_UPEU', '06:30'),
        ('CMB-520', 'UPEU_PLAZA', '08:00'), ('CMB-410', 'PLAZA_UPEU', '08:00'),
        ('CMB-410', 'UPEU_PLAZA', '12:30'), ('CMB-520', 'PLAZA_UPEU', '12:30'),
        ('CMB-520', 'UPEU_PLAZA', '18:00'), ('CMB-410', 'PLAZA_UPEU', '18:00')
     ) AS s(placa, sentido, hora)
JOIN public.vehiculo v ON v.placa = s.placa;

-- Clientes de ejemplo
INSERT INTO public.cliente (dni, nombres, telefono, tipo_documento) VALUES
    ('70123456', 'CARLOS QUISPE MAMANI',  '951234567', 'DNI'),
    ('72654321', 'MARIA APAZA CONDORI',   '987654321', 'DNI'),
    ('74111222', 'JOSE HUANCA TICONA',    NULL,        'DNI');


-- =====================================================================
-- 3. VENTA DE EJEMPLO (mismo flujo que hace el sistema)
--    Carlos compra los asientos 1 y 2 del taxi TAX-101 de las 07:00 (UPeU -> Plaza)
-- =====================================================================

-- 3.1 Reserva en el carrito
INSERT INTO public.venta_carrito (dni, id_viaje, nro_asiento, precio, estado, id_usuario, fecha_reg)
SELECT '70123456', vi.id_viaje, a.nro, vi.precio, 1, u.id_usuario, CURRENT_TIMESTAMP
FROM public.viaje vi
JOIN public.vehiculo ve ON ve.id_vehiculo = vi.id_vehiculo
CROSS JOIN (VALUES (1), (2)) AS a(nro)
CROSS JOIN public.usuario u
WHERE ve.placa = 'TAX-101' AND vi.sentido = 'UPEU_PLAZA'
  AND vi.fecha = CURRENT_DATE AND vi.hora_salida = '07:00' AND u.usuario = 'Ronaldo';

-- 3.2 Registrar la venta en una transacción (cabecera + boletos + vaciar carrito)
BEGIN;

INSERT INTO public.venta_pasaje (precio_base, igv, descuento, precio_total, serie, num_doc,
                                 tipo_doc, fecha_venta, dni, id_usuario)
SELECT ROUND((SUM(c.precio) / 1.18)::NUMERIC, 2),
       ROUND((SUM(c.precio) - SUM(c.precio) / 1.18)::NUMERIC, 2),
       0,
       SUM(c.precio),
       'B001', 'PENDIENTE', 'BOLETA', CURRENT_TIMESTAMP, c.dni, MIN(c.id_usuario)
FROM public.venta_carrito c
WHERE c.dni = '70123456'
GROUP BY c.dni;

-- Número correlativo de la boleta: B001-00000001
UPDATE public.venta_pasaje
SET num_doc = LPAD(id_venta::TEXT, 8, '0')
WHERE num_doc = 'PENDIENTE';

INSERT INTO public.boleto (id_venta, id_viaje, nro_asiento, precio)
SELECT currval('public.venta_pasaje_id_venta_seq'), c.id_viaje, c.nro_asiento, c.precio
FROM public.venta_carrito c
WHERE c.dni = '70123456';

DELETE FROM public.venta_carrito WHERE dni = '70123456';

COMMIT;


-- =====================================================================
-- 4. DML DE EJEMPLO (C, R, U, D) - igual que dmls.sql del ejemplo
-- =====================================================================

--C
INSERT INTO public.vehiculo (id_vehiculo, placa, tipo_vehiculo, marca_modelo, conductor, color, asientos, estado)
VALUES (nextval('public.vehiculo_id_vehiculo_seq'::regclass), 'TAX-909', 'TAXI', 'Suzuki Swift',
        'Ana Coaquira Pari', 'Amarillo', 4, 'ACTIVO');
--R
SELECT id_vehiculo, placa, tipo_vehiculo, asientos, conductor, estado
FROM public.vehiculo
ORDER BY tipo_vehiculo DESC, placa;
--U
UPDATE public.vehiculo
SET conductor = 'Ana Coaquira Pari de Mamani', color = 'Blanco'
WHERE placa = 'TAX-909';
--D (solo si no tiene salidas programadas)
DELETE FROM public.vehiculo
WHERE placa = 'TAX-909';

-- Cancelar una salida (no se elimina si ya tiene boletos)
-- UPDATE public.viaje SET estado = 'CANCELADO' WHERE id_viaje = 5;


-- =====================================================================
-- 5. CONSULTAS Y REPORTES
-- =====================================================================

-- 5.1 Salidas disponibles de hoy con asientos libres (lo que muestra "Vender pasaje")
SELECT vi.id_viaje,
       TO_CHAR(vi.hora_salida, 'HH24:MI') AS salida,
       CASE vi.sentido WHEN 'UPEU_PLAZA' THEN 'Universidad UPeU -> C.C. Plaza de Armas'
                       ELSE 'C.C. Plaza de Armas -> Universidad UPeU' END AS ruta,
       ve.tipo_vehiculo, ve.placa, ve.conductor,
       ve.asientos
         - (SELECT COUNT(*) FROM public.boleto b WHERE b.id_viaje = vi.id_viaje)
         - (SELECT COUNT(*) FROM public.venta_carrito c WHERE c.id_viaje = vi.id_viaje) AS libres,
       ve.asientos AS capacidad,
       vi.precio
FROM public.viaje vi
JOIN public.vehiculo ve ON ve.id_vehiculo = vi.id_vehiculo
WHERE vi.fecha = CURRENT_DATE AND vi.estado = 'PROGRAMADO'
ORDER BY vi.hora_salida, vi.sentido;

-- 5.2 Asientos ocupados de una salida (vendidos + reservados)
--     Ejemplo: taxi TAX-101 de hoy a las 07:00, UPeU -> Plaza
WITH salida AS (
    SELECT vi.id_viaje
    FROM public.viaje vi
    JOIN public.vehiculo ve ON ve.id_vehiculo = vi.id_vehiculo
    WHERE ve.placa = 'TAX-101' AND vi.sentido = 'UPEU_PLAZA'
      AND vi.fecha = CURRENT_DATE AND vi.hora_salida = '07:00'
)
SELECT b.nro_asiento, 'VENDIDO' AS situacion
FROM public.boleto b WHERE b.id_viaje IN (SELECT id_viaje FROM salida)
UNION
SELECT c.nro_asiento, 'RESERVADO'
FROM public.venta_carrito c WHERE c.id_viaje IN (SELECT id_viaje FROM salida)
ORDER BY 1;

-- 5.3 Historial de ventas (boletas)
SELECT v.serie || '-' || v.num_doc AS boleta,
       TO_CHAR(v.fecha_venta, 'DD/MM/YYYY HH24:MI') AS fecha,
       p.dni, p.nombres AS cliente, u.usuario AS vendedor,
       (SELECT COUNT(*) FROM public.boleto b WHERE b.id_venta = v.id_venta) AS pasajes,
       v.descuento, v.precio_base, v.igv, v.precio_total
FROM public.venta_pasaje v
JOIN public.cliente p ON p.dni = v.dni
JOIN public.usuario u ON u.id_usuario = v.id_usuario
ORDER BY v.id_venta DESC;

-- 5.4 Detalle de una boleta
SELECT v.serie || '-' || v.num_doc AS boleta, b.nro_asiento,
       vi.sentido, vi.fecha, TO_CHAR(vi.hora_salida, 'HH24:MI') AS salida,
       ve.tipo_vehiculo, ve.placa, b.precio
FROM public.boleto b
JOIN public.venta_pasaje v ON v.id_venta = b.id_venta
JOIN public.viaje vi ON vi.id_viaje = b.id_viaje
JOIN public.vehiculo ve ON ve.id_vehiculo = vi.id_vehiculo
WHERE v.id_venta = 1
ORDER BY b.nro_asiento;

-- 5.5 Recaudación por día y tipo de vehículo
SELECT vi.fecha, ve.tipo_vehiculo,
       COUNT(*) AS pasajes_vendidos,
       SUM(b.precio) AS recaudado
FROM public.boleto b
JOIN public.viaje vi ON vi.id_viaje = b.id_viaje
JOIN public.vehiculo ve ON ve.id_vehiculo = vi.id_vehiculo
GROUP BY vi.fecha, ve.tipo_vehiculo
ORDER BY vi.fecha DESC, ve.tipo_vehiculo;

-- 5.6 Ocupación de cada salida de hoy (%)
SELECT TO_CHAR(vi.hora_salida, 'HH24:MI') AS salida, vi.sentido, ve.placa,
       COUNT(b.id_boleto) AS vendidos, ve.asientos,
       ROUND(100.0 * COUNT(b.id_boleto) / ve.asientos, 1) AS ocupacion_pct
FROM public.viaje vi
JOIN public.vehiculo ve ON ve.id_vehiculo = vi.id_vehiculo
LEFT JOIN public.boleto b ON b.id_viaje = vi.id_viaje
WHERE vi.fecha = CURRENT_DATE
GROUP BY vi.id_viaje, vi.hora_salida, vi.sentido, ve.placa, ve.asientos
ORDER BY vi.hora_salida, vi.sentido;

-- 5.7 Liberar reservas de carrito con más de 15 minutos
DELETE FROM public.venta_carrito
WHERE fecha_reg < CURRENT_TIMESTAMP - INTERVAL '15 minutes';
